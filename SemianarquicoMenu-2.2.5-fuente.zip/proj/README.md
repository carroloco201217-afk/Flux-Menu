# SemianarquicoMenu 2.2.5

Menú principal para servidor Paper/Purpur con soporte **Java + Bedrock**.

- **Java** → diálogos nativos de Paper  
- **Bedrock** → formularios con iconos (Floodgate); si fallan, menús de inventario (DeluxeMenus)  

Detecta jugadores Bedrock con Floodgate o por prefijo `BD_`.

## Compilar

El JAR se genera automáticamente con **GitHub Actions**:

1. Ve a la pestaña **Actions**
2. Cuando termine el build, descarga el artifact **SemianarquicoMenu**
3. Dentro del ZIP está el `.jar` listo para poner en `plugins/`

También puedes compilar localmente:

```bash
mvn clean package
```

## Instalación en el servidor

1. Pon `SemianarquicoMenu-2.2.5.jar` en `plugins/`
2. Copia los archivos de `DeluxeMenus/gui_menus/` a `plugins/DeluxeMenus/gui_menus/`
3. En `plugins/DeluxeMenus/config.yml` registra:

```yaml
gui_menus:
  flux_menu:
    file: flux_menu.yml
  kits:
    file: kits.yml
  warps:
    file: warps.yml
  rtp:
    file: rtp.yml
  stats:
    file: stats.yml
```

4. Reinicia o `/menu reload` + `/dm reload`

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/menu` | Abre el menú (Java o Bedrock según el cliente) |
| `/menu reload` | Recarga la config |
| `/kit` | Menú de kits |
| `/kit <nombre>` | Reclama un kit |
| `/kit create <nombre> <precio> [categoria]` | Crea kit (admin) |
| `/kit delete <nombre>` | Borra kit (admin) |
| `/kit desc <nombre> <texto>` | Cambia descripción (admin) |
| `/kit list` | Lista kits |
| `/warp` | Menú de warps |
| `/setwarp <nombre>` | Crea warp (admin) |
| `/delwarp <nombre>` | Borra warp (admin) |
| `/warpdesc <nombre> <texto>` | Descripción del warp (admin) |

## Requisitos

- Paper / Purpur 1.21+
- DeluxeMenus (para Bedrock)
- Floodgate + Geyser (recomendado)
- Vault (opcional, precios de kits)
- BetterRTP (opcional)

Más detalles en `docs/INSTRUCCIONES.md`.

## Novedades 2.2.5

- Formularios Bedrock: nombre con su color arriba y descripción debajo (`bedrock.formularios` en `config.yml`).
- Descripciones en blanco (`&f`) por defecto, y textos más cortos para que Bedrock no los corte con "...".
- Diálogos Java: `dialogos.formato-boton` controla si la descripción va en el botón o en el tooltip.
- Si ya tienes un `config.yml` en el servidor, copia las secciones nuevas (`dialogos` y `bedrock.formularios`) o bórralo para que se regenere.
- Los datos (`kits.yml`, `warps.yml`) viven en `plugins/SemianarquicoMenu/`.
