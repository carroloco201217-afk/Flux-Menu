# Flux - Menu 3.0.0

Menú principal para servidor Paper/Purpur con soporte **Java + Bedrock**.

- **Java** → diálogos nativos de Paper  
- **Bedrock** → formularios con iconos (Floodgate); si fallan, menús de inventario (DeluxeMenus)  

Detecta jugadores Bedrock con Floodgate o por prefijo `BD_`.

## Compilar

El JAR se genera automáticamente con **GitHub Actions**:

1. Ve a la pestaña **Actions**
2. Cuando termine el build, descarga el artifact **Flux-Menu**
3. Dentro del ZIP está el `.jar` listo para poner en `plugins/`

También puedes compilar localmente:

```bash
mvn clean package
```

## Instalación en el servidor

1. **Borra** `SemianarquicoMenu-*.jar` y pon `Flux-Menu-3.0.0.jar` en `plugins/`
2. Copia los archivos de `DeluxeMenus/gui_menus/` a `plugins/DeluxeMenus/gui_menus/`
3. En `plugins/DeluxeMenus/config.yml` registra:

```yaml
gui_menus:
  flux_menu:
    file: flux_menu.yml
  kits:
    file: kits.yml
  warps:
    file: warps.yml
  rtp:
    file: rtp.yml
  stats:
    file: stats.yml
```

4. Reinicia o `/menu reload` + `/dm reload`

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/menu` | Abre el menú (también como `/flux:menu`) |
| `/menu reload` | Recarga la config |
| `/kit` | Menú de kits |
| `/kit <nombre>` | Reclama un kit |
| `/kit create <nombre> <precio> [categoria]` | Crea kit (admin) |
| `/kit delete <nombre>` | Borra kit (admin) |
| `/kit desc <nombre> <texto>` | Cambia descripción (admin) |
| `/kit color <nombre> <códigos>` | Color/negrita del kit, ej. `&b&l` (admin) |
| `/kit icono <nombre> <textura\|auto>` | Textura del kit; `auto` = la de su categoría (admin) |
| `/kit list` | Lista kits |
| `/warp` | Menú de warps |
| `/setwarp <nombre>` | Crea warp (admin) |
| `/delwarp <nombre>` | Borra warp (admin) |
| `/warpdesc <nombre> <texto>` | Descripción del warp (admin) |

## Requisitos

- Paper / Purpur 1.21+
- DeluxeMenus (para Bedrock)
- Floodgate + Geyser (recomendado)
- Vault (opcional, precios de kits)
- BetterRTP (opcional)

Más detalles en `docs/INSTRUCCIONES.md`.

## Novedades 2.2.5

- Formularios Bedrock: nombre con su color arriba y descripción debajo (`bedrock.formularios` en `config.yml`).
- Descripciones en blanco (`&f`) por defecto, y textos más cortos para que Bedrock no los corte con "...".
- Diálogos Java: `dialogos.formato-boton` controla si la descripción va en el botón o en el tooltip.
- Si ya tienes un `config.yml` en el servidor, copia las secciones nuevas (`dialogos` y `bedrock.formularios`) o bórralo para que se regenere.
- Los datos (`kits.yml`, `warps.yml`) viven ahora en `plugins/Flux/`.

## Novedades 3.0.0 (Flux - Menu)

- **Nombre nuevo**: el plugin se llama **Flux** (`plugins/Flux/`). Por eso todos los comandos también existen con prefijo: `/flux:menu`, `/flux:kit`, `/flux:warp`, `/flux:setwarp`, `/flux:delwarp`, `/flux:warpdesc`.
- **Solo Bedrock** (`solo-bedrock` en `config.yml`): los jugadores de Java no pueden usar los menús. Se puede apagar con `activar: false`, elegir qué partes se bloquean y a qué comando se redirige a Java (por defecto `/kit` va a PlayerKits2).
- **Textura automática por categoría** al mostrar los kits (`icono-kit` en cada categoría) y `/kit icono` para cambiarla a mano.
- **Categoría nueva KITS UTILIDAD**, debajo de Dinero: `/kit create <nombre> <precio> utilidad`.
- **Precios abreviados**: `1.0k`, `1.0M`, `1.0B` (sección `precio`). Al crear kits también se escribe así: `/kit create inicio 1k`.
- **Botón decorado**: `NOMBRE` arriba y `Comprar - 1.0k` abajo (`formato-kit` y `formato-kit-gratis`).
- **Color y negrita por kit**: al crearlo se guarda `&e&l` (`kits.color-por-defecto`); se cambia con `/kit color`.
- Casi todo lo que antes estaba escrito en el código ahora está en `config.yml`: precios, textos de los diálogos, permisos (`permisos`), categoría por defecto, etc.
- Al arrancar por primera vez copia `kits.yml` y `warps.yml` de `plugins/SemianarquicoMenu/` y reconoce el item FLUX MENU que ya tienen los jugadores.

## Novedades 3.1.0

- Categorias de kits editables: `/kit categoria` (editor Bedrock) o `/kit categoria crear|editar|borrar|restaurar|lista`. Se guardan en `categorias.yml`.
- Homes (maximo 6, configurable): `/home`, `/sethome`, `/delhome`, `/homes` y menu Bedrock.
- Menu de clanes (`/clanes`): crear, unirse, salir, miembros e invitaciones. Ejecuta los comandos de tu plugin de clanes (`clanes.comandos`).
- Texturas: iconos `@nombre` que cargan la imagen de `texturas.base-url`.
