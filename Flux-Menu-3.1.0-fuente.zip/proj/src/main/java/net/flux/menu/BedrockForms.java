package net.flux.menu;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.util.FormImage;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Formularios Bedrock (SimpleForm de Cumulus enviados con Floodgate).
 *
 * Cada boton se ve asi:
 *
 *     [ WARPS ]                 <- nombre, con su color
 *     Zonas de minas, PvP...    <- descripcion en la linea de abajo
 *
 * El formato sale de bedrock.formularios.formato-boton del config.yml.
 * Esta clase solo se carga si Floodgate esta instalado.
 */
final class BedrockForms {

    private static final String FORMATO_BOTON = "&f[ {nombre}&f ]\n{descripcion}";

    private final FluxMenu plugin;

    BedrockForms(FluxMenu plugin) {
        this.plugin = plugin;
        // Si falta Floodgate/Cumulus esto lanza NoClassDefFoundError y el plugin usa DeluxeMenus
        FloodgateApi.getInstance();
    }

    // ================================================================ utilidades

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    /** Convierte &c en codigos de color de Bedrock; quita la negrita si esta desactivada. */
    private String color(String texto) {
        if (texto == null) return "";
        if (!cfg().getBoolean("bedrock.formularios.negrita", false)) {
            texto = texto.replaceAll("(?i)&l", "");
        }
        return texto.replace('&', '\u00a7');
    }

    /** Boton con nombre arriba y descripcion debajo. */
    private String textoBoton(String formato, String nombre, String descripcion) {
        boolean hayDesc = descripcion != null && !descripcion.isBlank();
        if (!hayDesc) {
            return color(cfg().getString("bedrock.formularios.formato-boton-sin-descripcion", "&f[ {nombre}&f ]")
                    .replace("{nombre}", nombre == null ? "" : nombre));
        }
        return color(formato
                .replace("{nombre}", nombre == null ? "" : nombre)
                .replace("{descripcion}", descripcion));
    }

    private void icono(SimpleForm.Builder form, String texto, String iconoConfig) {
        String icono = plugin.resolverIcono(iconoConfig);
        if (icono == null || icono.isBlank()) {
            form.button(texto);
        } else if (icono.startsWith("http://") || icono.startsWith("https://")) {
            form.button(texto, FormImage.Type.URL, icono);
        } else {
            form.button(texto, FormImage.Type.PATH, icono);
        }
    }

    private void enviar(Player p, SimpleForm.Builder form, List<Runnable> acciones) {
        form.validResultHandler(respuesta -> {
            int i = respuesta.clickedButtonId();
            if (i < 0 || i >= acciones.size()) return;
            Runnable accion = acciones.get(i);
            if (accion != null) Bukkit.getScheduler().runTask(plugin, accion);
        });
        if (!FloodgateApi.getInstance().sendForm(p.getUniqueId(), form.build())) {
            throw new IllegalStateException("Floodgate no pudo enviar el formulario a " + p.getName());
        }
    }

    // ================================================================ menu principal

    void principal(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.principal.titulo",
                        c.getString("menu.titulo", "MENU"))))
                .content(color(c.getString("bedrock.formularios.principal.descripcion",
                        c.getString("menu.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        ConfigurationSection botones = c.getConfigurationSection("menu.botones");
        if (botones != null) {
            for (String id : botones.getKeys(false)) {
                ConfigurationSection b = botones.getConfigurationSection(id);
                if (b == null) continue;
                String abre = b.getString("abre", "").toLowerCase(Locale.ROOT);
                String comando = b.getString("comando", "");
                icono(form, textoBoton(formato, b.getString("nombre", id), b.getString("descripcion")),
                        b.getString("icono", ""));
                acciones.add(() -> {
                    if (abre.equals("kits")) plugin.abrirMenuKits(p);
                    else if (abre.equals("warps")) plugin.abrirMenuWarps(p);
                    else if (abre.equals("homes")) plugin.abrirMenuHomes(p);
                    else if (abre.equals("clanes")) plugin.abrirMenuClanes(p);
                    else plugin.ejecutar(p, comando);
                });
            }
        }
        enviar(p, form, acciones);
    }

    // ================================================================ kits

    void kits(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.kits.titulo",
                        c.getString("kits.titulo", "KITS"))))
                .content(color(c.getString("bedrock.formularios.kits.descripcion",
                        c.getString("kits.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String cat : plugin.categorias()) {
            icono(form, textoBoton(formato, plugin.catTexto(cat, "nombre", cat), plugin.catTexto(cat, "descripcion", "")),
                    plugin.catTexto(cat, "icono", ""));
            acciones.add(() -> plugin.abrirCategoriaKits(p, cat));
        }
        icono(form, color(c.getString("kits.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.kits.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    void categoria(Player p, String cat) {
        FileConfiguration c = cfg();
        if (!plugin.existeCategoria(cat)) return;

        List<String> kits = plugin.nombresKits(cat);
        String formatoKit = c.getString("bedrock.formularios.categoria.formato-kit",
                "{kit}\n&aComprar &8- {precio}");
        String formatoGratis = c.getString("bedrock.formularios.categoria.formato-kit-gratis",
                "{kit}\n{precio}");
        boolean respetarNegrita = c.getBoolean("kits.respetar-negrita", true);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(plugin.catTexto(cat, "titulo", plugin.catTexto(cat, "nombre", cat))))
                .content(color(kits.isEmpty()
                        ? c.getString("bedrock.formularios.categoria.descripcion-vacia",
                                "&7Todavia no hay kits en esta categoria.")
                        : c.getString("bedrock.formularios.categoria.descripcion",
                                "&fHaz click en un kit para obtenerlo:")));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : kits) {
            String desc = plugin.descripcionKit(nombre);
            double valor = plugin.precioKit(nombre);
            String precio = plugin.precioTxt(valor);
            String plantilla = valor <= 0 ? formatoGratis : formatoKit;
            // el nombre lleva SU color (y negrita); se pasa ya convertido para que color() no le quite la &l
            String kitTxt = plugin.nombreKitTxt(nombre);
            if (!respetarNegrita) kitTxt = kitTxt.replaceAll("(?i)&l", "");
            kitTxt = kitTxt.replace('&', '\u00a7');
            icono(form, color(plantilla
                            .replace("{kit}", kitTxt)
                            .replace("{precio}", precio)
                            .replace("{descripcion}", desc)),
                    plugin.iconoKit(nombre));
            acciones.add(() -> plugin.reclamarKit(p, nombre));
        }
        icono(form, color(c.getString("bedrock.formularios.categoria.volver", "&7Volver a las categorias")),
                c.getString("bedrock.formularios.categoria.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuKits(p));
        enviar(p, form, acciones);
    }

    // ================================================================ warps

    void warps(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.warps.formato",
                "&f[ &b{nombre}&f ]\n{descripcion}");
        String porDefecto = c.getString("warps.descripcion-por-defecto", "");

        List<String> nombres = plugin.nombresWarps();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.warps.titulo",
                        c.getString("warps.titulo", "WARPS"))))
                .content(color(nombres.isEmpty()
                        ? c.getString("warps.sin-warps", "&7Todavia no hay warps creados.")
                        : c.getString("bedrock.formularios.warps.descripcion",
                                c.getString("warps.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : nombres) {
            String desc = plugin.descripcionWarp(nombre);
            if (desc.isBlank()) desc = porDefecto;
            icono(form, textoBoton(formato, nombre.toUpperCase(Locale.ROOT), desc),
                    c.getString("bedrock.formularios.warps.icono", "textures/items/ender_pearl"));
            acciones.add(() -> plugin.irAWarp(p, nombre));
        }
        icono(form, color(c.getString("warps.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.warps.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    // ================================================================ utilidades de formularios

    private void enviarCustom(Player p, CustomForm.Builder form) {
        if (!FloodgateApi.getInstance().sendForm(p.getUniqueId(), form.build())) {
            throw new IllegalStateException("Floodgate no pudo enviar el formulario a " + p.getName());
        }
    }

    private String t(String clave, String def) {
        return color(cfg().getString(clave, def));
    }

    // ================================================================ homes

    void homes(Player p) {
        FileConfiguration c = cfg();
        List<String> homes = plugin.nombresHomes(p);
        int max = plugin.maxHomes();
        String formato = c.getString("homes.formato-boton", "&f[ &b{home}&f ]\n{ubicacion}");

        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("homes.titulo", "&b&lHOMES"))
                .content(color((homes.isEmpty()
                        ? c.getString("homes.sin-homes", "&7Aun no tienes homes. Crea uno abajo.")
                        : c.getString("homes.descripcion", "&fTienes {n}/{max} homes. Elige uno:"))
                        .replace("{n}", String.valueOf(homes.size()))
                        .replace("{max}", String.valueOf(max))));

        List<Runnable> acciones = new ArrayList<>();
        for (String h : homes) {
            icono(form, color(formato
                            .replace("{home}", h.toUpperCase(Locale.ROOT))
                            .replace("{ubicacion}", plugin.descripcionHome(p, h))),
                    c.getString("homes.icono-home", "@profile_glyph_color"));
            acciones.add(() -> homeOpciones(p, h));
        }
        if (homes.size() < max) {
            icono(form, t("homes.boton-crear", "&a[ Crear nuevo home ]\n&fGuarda tu posicion actual"),
                    c.getString("homes.icono-crear", "@mashup_PaintBrush"));
            acciones.add(() -> crearHomeForm(p));
        }
        icono(form, t("homes.volver", "&7Volver al Menu Principal"),
                c.getString("homes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    private void homeOpciones(Player p, String home) {
        FileConfiguration c = cfg();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("homes.opciones.titulo", "&b&lHOME {home}")
                        .replace("{home}", home.toUpperCase(Locale.ROOT))))
                .content(color(plugin.descripcionHome(p, home)));
        List<Runnable> acciones = new ArrayList<>();

        icono(form, t("homes.opciones.ir", "&a[ Ir al home ]\n&fTeletransportarme"),
                c.getString("homes.opciones.icono-ir", "@warps"));
        acciones.add(() -> plugin.irAHome(p, home));

        icono(form, t("homes.opciones.mover", "&e[ Mover aqui ]\n&fGuardar mi posicion actual"),
                c.getString("homes.opciones.icono-mover", "@mashup_PaintBrush"));
        acciones.add(() -> {
            plugin.crearHome(p, home);
            plugin.abrirMenuHomes(p);
        });

        icono(form, t("homes.opciones.borrar", "&c[ Borrar home ]\n&fEsto no se puede deshacer"),
                c.getString("homes.opciones.icono-borrar", "@garbage"));
        acciones.add(() -> {
            plugin.borrarHome(p, home);
            plugin.abrirMenuHomes(p);
        });

        icono(form, t("homes.volver-homes", "&7Volver a mis homes"),
                c.getString("homes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuHomes(p));
        enviar(p, form, acciones);
    }

    private void crearHomeForm(Player p) {
        FileConfiguration c = cfg();
        CustomForm.Builder form = CustomForm.builder()
                .title(t("homes.crear.titulo", "&b&lNUEVO HOME"))
                .input(color(c.getString("homes.crear.etiqueta", "&fNombre del home (letras y numeros, max 16)")),
                        c.getString("homes.crear.ejemplo", "casa"), "")
                .validResultHandler(respuesta -> {
                    String nombre = respuesta.asInput(0);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        plugin.crearHome(p, nombre == null ? "" : nombre);
                        plugin.abrirMenuHomes(p);
                    });
                });
        enviarCustom(p, form);
    }

    // ================================================================ clanes

    void clanes(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("clanes.titulo", "&c&lCLANES"))
                .content(t("clanes.descripcion", "&fElige una opcion:"));
        List<Runnable> acciones = new ArrayList<>();

        botonClan(form, acciones, formato, "crear", "&a&lCREAR UN CLAN", "&fFunda tu propio clan", "@mashup_PaintBrush",
                () -> clanEntrada(p, "crear", "crear"));
        botonClan(form, acciones, formato, "unirse", "&b&lUNIRSE A UN CLAN", "&fEntra a un clan por su nombre", "@vender",
                () -> clanEntrada(p, "unirse", "unirse"));
        botonClan(form, acciones, formato, "salir", "&c&lSALIR DEL CLAN", "&fAbandona tu clan actual", "@ErrorGlyph",
                () -> clanConfirmarSalir(p));
        botonClan(form, acciones, formato, "miembros", "&e&lMIEMBROS DEL CLAN", "&fMira quien esta en tu clan", "@servers",
                () -> plugin.clanComando(p, "miembros", ""));
        botonClan(form, acciones, formato, "invitaciones", "&d&lINVITACIONES", "&fInvita, acepta o rechaza", "@Feedback",
                () -> clanInvitaciones(p));

        icono(form, t("clanes.volver", "&7Volver al Menu Principal"),
                c.getString("clanes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    private void botonClan(SimpleForm.Builder form, List<Runnable> acciones, String formato, String id,
                           String nombreDef, String descDef, String iconoDef, Runnable accion) {
        FileConfiguration c = cfg();
        String base = "clanes.botones." + id + ".";
        icono(form, textoBoton(formato, c.getString(base + "nombre", nombreDef), c.getString(base + "descripcion", descDef)),
                c.getString(base + "icono", iconoDef));
        acciones.add(accion);
    }

    /** Formulario con un cuadro de texto; lo escrito se manda al comando clanes.comandos.<clave>. */
    private void clanEntrada(Player p, String clave, String textos) {
        FileConfiguration c = cfg();
        CustomForm.Builder form = CustomForm.builder()
                .title(t("clanes." + textos + ".titulo", "&c&lCLAN"))
                .input(color(c.getString("clanes." + textos + ".etiqueta", "&fEscribe el nombre del clan")),
                        c.getString("clanes." + textos + ".ejemplo", "MiClan"), "")
                .validResultHandler(respuesta -> {
                    String valor = respuesta.asInput(0);
                    Bukkit.getScheduler().runTask(plugin, () -> plugin.clanComando(p, clave, valor == null ? "" : valor));
                });
        enviarCustom(p, form);
    }

    private void clanConfirmarSalir(Player p) {
        FileConfiguration c = cfg();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("clanes.salir.titulo", "&c&lSALIR DEL CLAN"))
                .content(t("clanes.salir.descripcion", "&fSeguro que quieres salir de tu clan?"));
        List<Runnable> acciones = new ArrayList<>();
        icono(form, t("clanes.salir.si", "&c[ Si, salir ]"), c.getString("clanes.salir.icono-si", "@ErrorGlyph"));
        acciones.add(() -> plugin.clanComando(p, "salir", ""));
        icono(form, t("clanes.salir.no", "&a[ Cancelar ]"), c.getString("clanes.salir.icono-no", "textures/items/arrow"));
        acciones.add(() -> clanes(p));
        enviar(p, form, acciones);
    }

    private void clanInvitaciones(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("clanes.invitaciones.titulo", "&d&lINVITACIONES"))
                .content(t("clanes.invitaciones.descripcion", "&fElige una opcion:"));
        List<Runnable> acciones = new ArrayList<>();
        String base = "clanes.invitaciones.";

        icono(form, textoBoton(formato, c.getString(base + "invitar.nombre", "&a&lINVITAR A UN JUGADOR"),
                        c.getString(base + "invitar.descripcion", "&fInvita a alguien a tu clan")),
                c.getString(base + "invitar.icono", "@vender"));
        acciones.add(() -> clanEntrada(p, "invitar", "invitaciones.invitar"));

        icono(form, textoBoton(formato, c.getString(base + "aceptar.nombre", "&b&lACEPTAR INVITACION"),
                        c.getString(base + "aceptar.descripcion", "&fUnete al clan que te invito")),
                c.getString(base + "aceptar.icono", "@win"));
        acciones.add(() -> plugin.clanComando(p, "aceptar", ""));

        icono(form, textoBoton(formato, c.getString(base + "rechazar.nombre", "&c&lRECHAZAR INVITACION"),
                        c.getString(base + "rechazar.descripcion", "&fIgnora la invitacion")),
                c.getString(base + "rechazar.icono", "@garbage"));
        acciones.add(() -> plugin.clanComando(p, "rechazar", ""));

        icono(form, t("clanes.volver-clanes", "&7Volver a clanes"), c.getString("clanes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> clanes(p));
        enviar(p, form, acciones);
    }

    // ================================================================ editor de categorias (admins)

    void editorCategorias(Player p) {
        FileConfiguration c = cfg();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("categorias-editor.titulo", "&6&lEDITOR DE CATEGORIAS"))
                .content(t("categorias-editor.descripcion", "&fElige una categoria para editarla o crea una nueva:"));
        List<Runnable> acciones = new ArrayList<>();
        for (String cat : plugin.categorias()) {
            icono(form, color("&f[ " + plugin.catTexto(cat, "nombre", cat) + "&f ]\n&7" + cat),
                    plugin.catTexto(cat, "icono", ""));
            acciones.add(() -> editarCategoriaForm(p, cat));
        }
        icono(form, t("categorias-editor.crear", "&a[ Crear categoria nueva ]"),
                c.getString("categorias-editor.icono-crear", "@mashup_PaintBrush"));
        acciones.add(() -> crearCategoriaForm(p));
        enviar(p, form, acciones);
    }

    private void crearCategoriaForm(Player p) {
        CustomForm.Builder form = CustomForm.builder()
                .title(t("categorias-editor.crear-titulo", "&a&lNUEVA CATEGORIA"))
                .input(color("&fId (letras minusculas, numeros, - y _)"), "vip", "")
                .input(color("&fNombre con colores (ej: &b&lKITS VIP)"), "&b&lKITS VIP", "")
                .validResultHandler(respuesta -> {
                    String id = respuesta.asInput(0);
                    String nombre = respuesta.asInput(1);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        String error = plugin.crearCategoria(id == null ? "" : id.trim(), nombre == null ? "" : nombre);
                        String idLimpio = id == null ? "" : id.trim().toLowerCase(Locale.ROOT);
                        if (error != null) {
                            p.sendMessage(plugin.msg(error, "id", idLimpio));
                            editorCategorias(p);
                        } else {
                            p.sendMessage(plugin.msg("categoria-creada", "id", idLimpio));
                            editarCategoriaForm(p, idLimpio);
                        }
                    });
                });
        enviarCustom(p, form);
    }

    private void editarCategoriaForm(Player p, String id) {
        String[] campos = {"nombre", "titulo", "descripcion", "icono", "icono-kit", "permiso"};
        String[] etiquetas = {"Nombre del boton", "Titulo de la ventana", "Descripcion",
                "Icono (@nombre, textures/... o https://...)", "Icono de los kits", "Permiso (vacio = todos)"};
        CustomForm.Builder form = CustomForm.builder()
                .title(color("&6&lEDITAR " + id.toUpperCase(Locale.ROOT)));
        for (int i = 0; i < campos.length; i++) {
            form.input(color("&f" + etiquetas[i]), "", plugin.catTexto(id, campos[i], ""));
        }
        form.input(color("&fMostrar tambien kits de (ids separados por coma)"), "dinero,utilidad",
                String.join(",", plugin.catLista(id, "mostrar-tambien")));
        form.toggle(color("&cBorrar esta categoria"), false);
        form.validResultHandler(respuesta -> {
            String[] nuevos = new String[campos.length + 1];
            for (int i = 0; i < nuevos.length; i++) {
                String v = respuesta.asInput(i);
                nuevos[i] = v == null ? "" : v;
            }
            boolean borrar = respuesta.asToggle(campos.length + 1);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (borrar) {
                    String error = plugin.borrarCategoria(id);
                    p.sendMessage(plugin.msg(error != null ? error : "categoria-borrada", "id", id));
                } else {
                    for (int i = 0; i < campos.length; i++) {
                        if (!nuevos[i].equals(plugin.catTexto(id, campos[i], ""))) {
                            plugin.editarCategoria(id, campos[i], nuevos[i]);
                        }
                    }
                    String mostrar = String.join(",", plugin.catLista(id, "mostrar-tambien"));
                    if (!nuevos[campos.length].equals(mostrar)) {
                        plugin.editarCategoria(id, "mostrar-tambien", nuevos[campos.length]);
                    }
                    p.sendMessage(plugin.msg("categoria-editada", "id", id));
                }
                editorCategorias(p);
            });
        });
        enviarCustom(p, form);
    }
}
