package net.flux.menu;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.util.FormImage;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Formularios Bedrock (SimpleForm de Cumulus enviados con Floodgate).
 *
 * Cada boton se ve asi:
 *
 *     [ WARPS ]                 <- nombre, con su color
 *     Zonas de minas, PvP...    <- descripcion en la linea de abajo
 *
 * El formato sale de bedrock.formularios.formato-boton del config.yml.
 * Esta clase solo se carga si Floodgate esta instalado.
 */
final class BedrockForms {

    private static final String FORMATO_BOTON = "&f[ {nombre}&f ]\n{descripcion}";

    private final FluxMenu plugin;

    BedrockForms(FluxMenu plugin) {
        this.plugin = plugin;
        // Si falta Floodgate/Cumulus esto lanza NoClassDefFoundError y el plugin usa DeluxeMenus
        FloodgateApi.getInstance();
    }

    // ================================================================ utilidades

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    /** Convierte &c en codigos de color de Bedrock; quita la negrita si esta desactivada. */
    private String color(String texto) {
        if (texto == null) return "";
        if (!cfg().getBoolean("bedrock.formularios.negrita", false)) {
            texto = texto.replaceAll("(?i)&l", "");
        }
        return texto.replace('&', '\u00a7');
    }

    /** Boton con nombre arriba y descripcion debajo. */
    private String textoBoton(String formato, String nombre, String descripcion) {
        boolean hayDesc = descripcion != null && !descripcion.isBlank();
        if (!hayDesc) {
            return color(cfg().getString("bedrock.formularios.formato-boton-sin-descripcion", "&f[ {nombre}&f ]")
                    .replace("{nombre}", nombre == null ? "" : nombre));
        }
        return color(formato
                .replace("{nombre}", nombre == null ? "" : nombre)
                .replace("{descripcion}", descripcion));
    }

    private void icono(SimpleForm.Builder form, String texto, String iconoConfig) {
        String icono = plugin.resolverIcono(iconoConfig);
        if (icono == null || icono.isBlank()) {
            form.button(texto);
        } else if (icono.startsWith("http://") || icono.startsWith("https://")) {
            form.button(texto, FormImage.Type.URL, icono);
        } else {
            form.button(texto, FormImage.Type.PATH, icono);
        }
    }

    private void enviar(Player p, SimpleForm.Builder form, List<Runnable> acciones) {
        form.validResultHandler(respuesta -> {
            int i = respuesta.clickedButtonId();
            if (i < 0 || i >= acciones.size()) return;
            Runnable accion = acciones.get(i);
            if (accion != null) Bukkit.getScheduler().runTask(plugin, accion);
        });
        if (!FloodgateApi.getInstance().sendForm(p.getUniqueId(), form.build())) {
            throw new IllegalStateException("Floodgate no pudo enviar el formulario a " + p.getName());
        }
    }

    // ================================================================ menu principal

    void principal(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.principal.titulo",
                        c.getString("menu.titulo", "MENU"))))
                .content(color(c.getString("bedrock.formularios.principal.descripcion",
                        c.getString("menu.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        ConfigurationSection botones = c.getConfigurationSection("menu.botones");
        if (botones != null) {
            for (String id : botones.getKeys(false)) {
                ConfigurationSection b = botones.getConfigurationSection(id);
                if (b == null) continue;
                String abre = b.getString("abre", "").toLowerCase(Locale.ROOT);
                String comando = b.getString("comando", "");
                icono(form, textoBoton(formato, b.getString("nombre", id), b.getString("descripcion")),
                        b.getString("icono", ""));
                acciones.add(() -> {
                    if (abre.equals("kits")) plugin.abrirMenuKits(p);
                    else if (abre.equals("warps")) plugin.abrirMenuWarps(p);
                    else if (abre.equals("homes")) plugin.abrirMenuHomes(p);
                    else if (abre.equals("clanes")) plugin.abrirMenuClanes(p);
                    else plugin.ejecutar(p, comando);
                });
            }
        }
        enviar(p, form, acciones);
    }

    // ================================================================ kits

    void kits(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.kits.titulo",
                        c.getString("kits.titulo", "KITS"))))
                .content(color(c.getString("bedrock.formularios.kits.descripcion",
                        c.getString("kits.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String cat : plugin.categorias()) {
            icono(form, textoBoton(formato, plugin.catTexto(cat, "nombre", cat), plugin.catTexto(cat, "descripcion", "")),
                    plugin.catTexto(cat, "icono", ""));
            acciones.add(() -> plugin.abrirCategoriaKits(p, cat));
        }
        icono(form, color(c.getString("kits.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.kits.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    void categoria(Player p, String cat) {
        FileConfiguration c = cfg();
        if (!plugin.existeCategoria(cat)) return;

        List<String> kits = plugin.nombresKits(cat);
        String formatoKit = c.getString("bedrock.formularios.categoria.formato-kit",
                "{kit}\n&aComprar &8- {precio}");
        String formatoGratis = c.getString("bedrock.formularios.categoria.formato-kit-gratis",
                "{kit}\n{precio}");
        boolean respetarNegrita = c.getBoolean("kits.respetar-negrita", true);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(plugin.catTexto(cat, "titulo", plugin.catTexto(cat, "nombre", cat))))
                .content(color(kits.isEmpty()
                        ? c.getString("bedrock.formularios.categoria.descripcion-vacia",
                                "&7Todavia no hay kits en esta categoria.")
                        : c.getString("bedrock.formularios.categoria.descripcion",
                                "&fHaz click en un kit para obtenerlo:")));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : kits) {
            String desc = plugin.descripcionKit(nombre);
            double valor = plugin.precioKit(nombre);
            String precio = plugin.precioTxt(valor);
            String plantilla = valor <= 0 ? formatoGratis : formatoKit;
            // el nombre lleva SU color (y negrita); se pasa ya convertido para que color() no le quite la &l
            String kitTxt = plugin.nombreKitTxt(nombre);
            if (!respetarNegrita) kitTxt = kitTxt.replaceAll("(?i)&l", "");
            kitTxt = kitTxt.replace('&', '\u00a7');
            icono(form, color(plantilla
                            .replace("{kit}", kitTxt)
                            .replace("{precio}", precio)
                            .replace("{descripcion}", desc)),
                    plugin.iconoKit(nombre));
            acciones.add(() -> plugin.reclamarKit(p, nombre));
        }
        icono(form, color(c.getString("bedrock.formularios.categoria.volver", "&7Volver a las categorias")),
                c.getString("bedrock.formularios.categoria.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuKits(p));
        enviar(p, form, acciones);
    }

    // ================================================================ warps

    void warps(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.warps.formato",
                "&f[ &b{nombre}&f ]\n{descripcion}");
        String porDefecto = c.getString("warps.descripcion-por-defecto", "");

        List<String> nombres = plugin.nombresWarps();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.warps.titulo",
                        c.getString("warps.titulo", "WARPS"))))
                .content(color(nombres.isEmpty()
                        ? c.getString("warps.sin-warps", "&7Todavia no hay warps creados.")
                        : c.getString("bedrock.formularios.warps.descripcion",
                                c.getString("warps.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : nombres) {
            String desc = plugin.descripcionWarp(nombre);
            if (desc.isBlank()) desc = porDefecto;
            icono(form, textoBoton(formato, nombre.toUpperCase(Locale.ROOT), desc),
                    c.getString("bedrock.formularios.warps.icono", "textures/items/ender_pearl"));
            acciones.add(() -> plugin.irAWarp(p, nombre));
        }
        icono(form, color(c.getString("warps.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.warps.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    // ================================================================ utilidades de formularios

    private void enviarCustom(Player p, CustomForm.Builder form) {
        if (!FloodgateApi.getInstance().sendForm(p.getUniqueId(), form.build())) {
            throw new IllegalStateException("Floodgate no pudo enviar el formulario a " + p.getName());
        }
    }

    private String t(String clave, String def) {
        return color(cfg().getString(clave, def));
    }

    // ================================================================ homes

    void homes(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);
        List<String> homes = plugin.nombresHomes(p);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("homes.titulo", "&b&lHOMES"))
                .content(color(c.getString("homes.descripcion", "&fTienes {n}/{max} homes. Elige una opcion:")
                        .replace("{n}", String.valueOf(homes.size()))
                        .replace("{max}", String.valueOf(plugin.maxHomes()))));
        List<Runnable> acciones = new ArrayList<>();

        botonHome(form, acciones, formato, "crear", "&a&lCREAR HOME", "&fGuarda tu posicion actual",
                "@mashup_PaintBrush", () -> {
                    if (plugin.nombresHomes(p).size() >= plugin.maxHomes()) {
                        p.sendMessage(plugin.msg("home-limite", "max", String.valueOf(plugin.maxHomes())));
                        homes(p);
                    } else {
                        crearHomeForm(p);
                    }
                });
        botonHome(form, acciones, formato, "ir", "&b&lIR A UN HOME", "&fTeletransportate a uno de tus homes",
                "@warps", () -> homesLista(p, true));
        botonHome(form, acciones, formato, "borrar", "&c&lBORRAR UN HOME", "&fElimina uno de tus homes",
                "@garbage", () -> homesLista(p, false));

        icono(form, t("homes.volver", "&7Volver al Menu Principal"),
                c.getString("homes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    private void botonHome(SimpleForm.Builder form, List<Runnable> acciones, String formato, String id,
                           String nombreDef, String descDef, String iconoDef, Runnable accion) {
        FileConfiguration c = cfg();
        String base = "homes.botones." + id + ".";
        icono(form, textoBoton(formato, c.getString(base + "nombre", nombreDef),
                        c.getString(base + "descripcion", descDef)),
                c.getString(base + "icono", iconoDef));
        acciones.add(accion);
    }

    /** Lista de tus homes: al tocar uno vas a el (ir = true) o te pide confirmar para borrarlo. */
    private void homesLista(Player p, boolean ir) {
        FileConfiguration c = cfg();
        String base = ir ? "homes.ir." : "homes.borrar.";
        List<String> homes = plugin.nombresHomes(p);
        String formato = c.getString("homes.formato-boton", "&f[ &b{home}&f ]\n{ubicacion}");

        SimpleForm.Builder form = SimpleForm.builder()
                .title(t(base + "titulo", ir ? "&a&lIR A UN HOME" : "&c&lBORRAR UN HOME"))
                .content(color(homes.isEmpty()
                        ? c.getString("homes.sin-homes", "&7Aun no tienes homes. Vuelve y elige CREAR HOME.")
                        : c.getString(base + "descripcion",
                                ir ? "&fElige a donde quieres ir:" : "&fElige el home que quieres borrar:")));
        List<Runnable> acciones = new ArrayList<>();
        for (String h : homes) {
            icono(form, color(formato
                            .replace("{home}", h.toUpperCase(Locale.ROOT))
                            .replace("{ubicacion}", plugin.descripcionHome(p, h))),
                    c.getString(base + "icono", ir ? "@warps" : "@garbage"));
            acciones.add(ir ? () -> plugin.irAHome(p, h) : () -> homeConfirmarBorrar(p, h));
        }
        icono(form, t("homes.volver-homes", "&7Volver a HOMES"),
                c.getString("homes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> homes(p));
        enviar(p, form, acciones);
    }

    private void homeConfirmarBorrar(Player p, String home) {
        FileConfiguration c = cfg();
        String nombre = home.toUpperCase(Locale.ROOT);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("homes.borrar.confirmar-titulo", "&c&lBORRAR {home}")
                        .replace("{home}", nombre)))
                .content(color(c.getString("homes.borrar.confirmar-descripcion",
                                "&fSeguro que quieres borrar el home &e{home}&f? Esto no se puede deshacer.")
                        .replace("{home}", nombre)));
        List<Runnable> acciones = new ArrayList<>();
        icono(form, t("homes.borrar.si", "&c[ Si, borrar ]"), c.getString("homes.borrar.icono-si", "@garbage"));
        acciones.add(() -> {
            plugin.borrarHome(p, home);
            homes(p);
        });
        icono(form, t("homes.borrar.no", "&a[ Cancelar ]"), c.getString("homes.borrar.icono-no", "textures/items/arrow"));
        acciones.add(() -> homesLista(p, false));
        enviar(p, form, acciones);
    }

    private void crearHomeForm(Player p) {
        FileConfiguration c = cfg();
        CustomForm.Builder form = CustomForm.builder()
                .title(t("homes.crear.titulo", "&b&lNUEVO HOME"))
                .input(color(c.getString("homes.crear.etiqueta", "&fNombre del home (letras y numeros, max 16)")),
                        c.getString("homes.crear.ejemplo", "casa"), "")
                .validResultHandler(respuesta -> {
                    String nombre = respuesta.asInput(0);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        plugin.crearHome(p, nombre == null ? "" : nombre);
                        homes(p);
                    });
                });
        enviarCustom(p, form);
    }

    // ================================================================ clanes
    // Los clanes los maneja tu plugin de clanes: cada boton ejecuta un comando de clanes.comandos.

    private record OpcionClan(String id, String nombre, String desc, String icono, Runnable accion) {}

    void clanes(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("clanes.titulo", "&c&lCLANES"))
                .content(t("clanes.descripcion", "&fElige una opcion:"));
        List<Runnable> acciones = new ArrayList<>();

        botonClan(form, acciones, formato, "crear", true, "&a&lCREAR CLAN", "&fFunda tu propio clan",
                "@mashup_PaintBrush", () -> clanEntrada(p, "crear", "crear"));
        botonClan(form, acciones, formato, "invitaciones", true, "&d&lINVITACIONES", "&fAcepta o rechaza invitaciones",
                "@Feedback", () -> clanInvitaciones(p));
        botonClan(form, acciones, formato, "tops", true, "&6&lVER TOPS", "&fTops de kills y dinero de los clanes",
                "@win", () -> clanTops(p));
        botonClan(form, acciones, formato, "base", true, "&b&lBASE DE CLAN", "&fVe a la base o fija la base",
                "@warps", () -> clanBase(p));
        botonClan(form, acciones, formato, "alianzas", true, "&a&lALIANZAS", "&fAliate con otros clanes",
                "@vender", () -> clanAlianzas(p));
        botonClan(form, acciones, formato, "borrar", true, "&c&lBORRAR CLAN", "&fElimina tu clan (solo el lider)",
                "@garbage", () -> clanConfirmar(p, "borrar"));
        botonClan(form, acciones, formato, "agregar", true, "&e&lAGREGAR MIEMBROS", "&fInvita a un jugador a tu clan",
                "@profile_glyph_color", () -> clanEntrada(p, "invitar", "agregar"));
        botonClan(form, acciones, formato, "miembros", true, "&f&lLISTAR MIEMBROS", "&fMira quien esta en tu clan",
                "@servers", () -> plugin.clanComando(p, "miembros", ""));
        // Ocultos por defecto (ponles mostrar: true en el config para usarlos)
        botonClan(form, acciones, formato, "unirse", false, "&b&lUNIRSE A UN CLAN", "&fEntra a un clan por su nombre",
                "@vender", () -> clanEntrada(p, "unirse", "unirse"));
        botonClan(form, acciones, formato, "salir", false, "&c&lSALIR DEL CLAN", "&fAbandona tu clan actual",
                "@ErrorGlyph", () -> clanConfirmar(p, "salir"));

        icono(form, t("clanes.volver", "&7Volver al Menu Principal"),
                c.getString("clanes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    private void botonClan(SimpleForm.Builder form, List<Runnable> acciones, String formato, String id,
                           boolean mostrarPorDefecto, String nombreDef, String descDef, String iconoDef,
                           Runnable accion) {
        FileConfiguration c = cfg();
        String base = "clanes.botones." + id + ".";
        if (!c.getBoolean(base + "mostrar", mostrarPorDefecto)) return;
        icono(form, textoBoton(formato, c.getString(base + "nombre", nombreDef), c.getString(base + "descripcion", descDef)),
                c.getString(base + "icono", iconoDef));
        acciones.add(accion);
    }

    /** Formulario con un cuadro de texto; lo escrito se manda al comando clanes.comandos.<clave>. */
    private void clanEntrada(Player p, String clave, String textos) {
        FileConfiguration c = cfg();
        CustomForm.Builder form = CustomForm.builder()
                .title(t("clanes." + textos + ".titulo", "&c&lCLAN"))
                .input(color(c.getString("clanes." + textos + ".etiqueta", "&fEscribe el nombre")),
                        c.getString("clanes." + textos + ".ejemplo", "MiClan"), "")
                .validResultHandler(respuesta -> {
                    String valor = respuesta.asInput(0);
                    Bukkit.getScheduler().runTask(plugin, () -> plugin.clanComando(p, clave, valor == null ? "" : valor));
                });
        enviarCustom(p, form);
    }

    /** Pregunta "seguro?" antes de borrar el clan (clave = borrar) o salir de el (clave = salir). */
    private void clanConfirmar(Player p, String clave) {
        FileConfiguration c = cfg();
        boolean borrar = clave.equals("borrar");
        String b = "clanes." + clave + ".";
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t(b + "titulo", borrar ? "&c&lBORRAR CLAN" : "&c&lSALIR DEL CLAN"))
                .content(t(b + "descripcion", borrar
                        ? "&fSeguro que quieres borrar tu clan? Esto no se puede deshacer."
                        : "&fSeguro que quieres salir de tu clan?"));
        List<Runnable> acciones = new ArrayList<>();
        icono(form, t(b + "si", borrar ? "&c[ Si, borrar ]" : "&c[ Si, salir ]"),
                c.getString(b + "icono-si", "@ErrorGlyph"));
        acciones.add(() -> plugin.clanComando(p, clave, ""));
        icono(form, t(b + "no", "&a[ Cancelar ]"), c.getString(b + "icono-no", "textures/items/arrow"));
        acciones.add(() -> clanes(p));
        enviar(p, form, acciones);
    }

    /** Submenu de clanes con varias opciones y un boton para volver a clanes. */
    private void clanSubmenu(Player p, String seccion, String tituloDef, String descDef, List<OpcionClan> ops) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("clanes." + seccion + ".titulo", tituloDef))
                .content(t("clanes." + seccion + ".descripcion", descDef));
        List<Runnable> acciones = new ArrayList<>();
        for (OpcionClan o : ops) {
            String base = "clanes." + seccion + "." + o.id() + ".";
            icono(form, textoBoton(formato, c.getString(base + "nombre", o.nombre()),
                            c.getString(base + "descripcion", o.desc())),
                    c.getString(base + "icono", o.icono()));
            acciones.add(o.accion());
        }
        icono(form, t("clanes.volver-clanes", "&7Volver a clanes"),
                c.getString("clanes.icono-volver", "textures/items/arrow"));
        acciones.add(() -> clanes(p));
        enviar(p, form, acciones);
    }

    private void clanInvitaciones(Player p) {
        clanSubmenu(p, "invitaciones", "&d&lINVITACIONES", "&fElige una opcion:", List.of(
                new OpcionClan("aceptar", "&b&lACEPTAR INVITACION", "&fUnete al clan que te invito",
                        "@win", () -> plugin.clanComando(p, "aceptar", "")),
                new OpcionClan("rechazar", "&c&lRECHAZAR INVITACION", "&fIgnora la invitacion",
                        "@garbage", () -> plugin.clanComando(p, "rechazar", ""))));
    }

    private void clanTops(Player p) {
        clanSubmenu(p, "tops", "&6&lTOPS DE CLANES", "&fElige que ranking quieres ver:", List.of(
                new OpcionClan("kills", "&c&lTOP KILLS", "&fLos clanes con mas kills",
                        "@ErrorGlyph", () -> plugin.clanComando(p, "top-kills", "")),
                new OpcionClan("dinero", "&e&lTOP DINERO", "&fLos clanes mas ricos",
                        "@coin", () -> plugin.clanComando(p, "top-dinero", ""))));
    }

    private void clanBase(Player p) {
        clanSubmenu(p, "base", "&b&lBASE DE CLAN", "&fElige una opcion:", List.of(
                new OpcionClan("ir", "&a&lIR A LA BASE", "&fTeletransportate a la base de tu clan",
                        "@warps", () -> clanEntrada(p, "base-ir", "base.ir")),
                new OpcionClan("fijar", "&e&lFIJAR BASE", "&fGuarda tu posicion como base del clan",
                        "@mashup_PaintBrush", () -> clanEntrada(p, "base-fijar", "base.fijar"))));
    }

    private void clanAlianzas(Player p) {
        clanSubmenu(p, "alianzas", "&a&lALIANZAS", "&fElige una opcion:", List.of(
                new OpcionClan("crear", "&a&lCREAR ALIANZA", "&fAliate con otro clan",
                        "@vender", () -> clanEntrada(p, "alianza-crear", "alianzas.crear")),
                new OpcionClan("romper", "&c&lROMPER ALIANZA", "&fTermina una alianza",
                        "@ErrorGlyph", () -> clanEntrada(p, "alianza-romper", "alianzas.romper")),
                new OpcionClan("lista", "&e&lVER ALIADOS", "&fLista de clanes aliados",
                        "@servers", () -> plugin.clanComando(p, "alianza-lista", ""))));
    }

    // ================================================================ editor de categorias (admins)

    void editorCategorias(Player p) {
        FileConfiguration c = cfg();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(t("categorias-editor.titulo", "&6&lEDITOR DE CATEGORIAS"))
                .content(t("categorias-editor.descripcion", "&fElige una categoria para editarla o crea una nueva:"));
        List<Runnable> acciones = new ArrayList<>();
        for (String cat : plugin.categorias()) {
            icono(form, color("&f[ " + plugin.catTexto(cat, "nombre", cat) + "&f ]\n&7" + cat),
                    plugin.catTexto(cat, "icono", ""));
            acciones.add(() -> editarCategoriaForm(p, cat));
        }
        icono(form, t("categorias-editor.crear", "&a[ Crear categoria nueva ]"),
                c.getString("categorias-editor.icono-crear", "@mashup_PaintBrush"));
        acciones.add(() -> crearCategoriaForm(p));
        enviar(p, form, acciones);
    }

    private void crearCategoriaForm(Player p) {
        CustomForm.Builder form = CustomForm.builder()
                .title(t("categorias-editor.crear-titulo", "&a&lNUEVA CATEGORIA"))
                .input(color("&fId (letras minusculas, numeros, - y _)"), "vip", "")
                .input(color("&fNombre con colores (ej: &b&lKITS VIP)"), "&b&lKITS VIP", "")
                .validResultHandler(respuesta -> {
                    String id = respuesta.asInput(0);
                    String nombre = respuesta.asInput(1);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        String error = plugin.crearCategoria(id == null ? "" : id.trim(), nombre == null ? "" : nombre);
                        String idLimpio = id == null ? "" : id.trim().toLowerCase(Locale.ROOT);
                        if (error != null) {
                            p.sendMessage(plugin.msg(error, "id", idLimpio));
                            editorCategorias(p);
                        } else {
                            p.sendMessage(plugin.msg("categoria-creada", "id", idLimpio));
                            editarCategoriaForm(p, idLimpio);
                        }
                    });
                });
        enviarCustom(p, form);
    }

    private void editarCategoriaForm(Player p, String id) {
        String[] campos = {"nombre", "titulo", "descripcion", "icono", "icono-kit", "permiso"};
        String[] etiquetas = {"Nombre del boton", "Titulo de la ventana", "Descripcion",
                "Icono (@nombre, textures/... o https://...)", "Icono de los kits", "Permiso (vacio = todos)"};
        CustomForm.Builder form = CustomForm.builder()
                .title(color("&6&lEDITAR " + id.toUpperCase(Locale.ROOT)));
        for (int i = 0; i < campos.length; i++) {
            form.input(color("&f" + etiquetas[i]), "", plugin.catTexto(id, campos[i], ""));
        }
        form.input(color("&fMostrar tambien kits de (ids separados por coma)"), "dinero,utilidad",
                String.join(",", plugin.catLista(id, "mostrar-tambien")));
        form.toggle(color("&cBorrar esta categoria"), false);
        form.validResultHandler(respuesta -> {
            String[] nuevos = new String[campos.length + 1];
            for (int i = 0; i < nuevos.length; i++) {
                String v = respuesta.asInput(i);
                nuevos[i] = v == null ? "" : v;
            }
            boolean borrar = respuesta.asToggle(campos.length + 1);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (borrar) {
                    String error = plugin.borrarCategoria(id);
                    p.sendMessage(plugin.msg(error != null ? error : "categoria-borrada", "id", id));
                } else {
                    for (int i = 0; i < campos.length; i++) {
                        if (!nuevos[i].equals(plugin.catTexto(id, campos[i], ""))) {
                            plugin.editarCategoria(id, campos[i], nuevos[i]);
                        }
                    }
                    String mostrar = String.join(",", plugin.catLista(id, "mostrar-tambien"));
                    if (!nuevos[campos.length].equals(mostrar)) {
                        plugin.editarCategoria(id, "mostrar-tambien", nuevos[campos.length]);
                    }
                    p.sendMessage(plugin.msg("categoria-editada", "id", id));
                }
                editorCategorias(p);
            });
        });
        enviarCustom(p, form);
    }
}
