# SemianarquicoMenu 2.1.0 – Menús separados Java / Bedrock

## ¿Qué soluciona esto?

Los **diálogos nativos de Paper** (los que usa tu plugin actual) se ven bien en Java, pero Geyser los traduce mal a Bedrock y se ven raros o incompletos.

**Solución:**
- Jugador **Java** → se siguen abriendo los **diálogos nativos** (como ahora).
- Jugador **Bedrock** → se abren **menús de inventario** de DeluxeMenus (los que ya tienes y se ven bien en Bedrock).

La detección se hace de dos formas (en este orden):
1. **Floodgate API** (si está instalado) → la más fiable.
2. **Prefijo del nombre** → por defecto `BD_` y `BD.` (configurable).

---

## Requisitos

- Paper / Purpur 1.21+
- Geyser + Floodgate (recomendado)
- DeluxeMenus (obligatorio para los menús Bedrock)
- Vault (opcional, para precios de kits)
- BetterRTP (opcional)

---

## Instalación paso a paso

### 1. Compilar el plugin (o usar el JAR si te lo doy compilado)

```bash
cd SemianarquicoMenu-v2.1
mvn clean package
```

El JAR sale en: `target/SemianarquicoMenu-2.1.0.jar`

Cópialo a `plugins/` de tu servidor y **borra o desactiva** la versión anterior (2.0.0).

### 2. Configurar DeluxeMenus (menús Bedrock)

Copia los archivos de la carpeta `DeluxeMenus/gui_menus/` a:

```
plugins/DeluxeMenus/gui_menus/
```

Archivos incluidos:
- `flux_menu.yml`  → menú principal Bedrock
- `kits.yml`       → menú de kits Bedrock (ajústalo a tus kits reales)
- `warps.yml`      → el que ya tenías
- `rtp.yml`        → el que ya tenías
- `stats.yml`      → el que ya tenías

Luego edita `plugins/DeluxeMenus/config.yml` y asegúrate de que tenga:

```yaml
gui_menus:
  flux_menu:
    file: flux_menu.yml
  kits:
    file: kits.yml
  rtp:
    file: rtp.yml
  stats:
    file: stats.yml
  warps:
    file: warps.yml
```

Reinicia o usa `/dm reload`.

### 3. Configurar SemianarquicoMenu

En `plugins/SemianarquicoMenu/config.yml` verás la sección nueva:

```yaml
bedrock:
  prefijos:
    - "BD_"
    - "BD."
  usar-floodgate: true
  menus:
    principal: "dm open flux_menu {jugador}"
    kits: "dm open kits {jugador}"
    warps: "dm open warps {jugador}"
    rtp: "dm open rtp {jugador}"
```

- Si Floodgate pone otro prefijo (ej. `.` o nada), cámbialo en `prefijos`.
- Los comandos de `menus` se ejecutan **desde la consola** con el nombre del jugador, para que DeluxeMenus abra el menú correctamente.

### 4. Floodgate – prefijo

En `plugins/floodgate/config.yml` (o el que uses) suele haber algo como:

```yaml
username-prefix: "BD_"
```

Asegúrate de que coincida con lo que tienes en `bedrock.prefijos` del plugin.

---

## Cómo funciona al usar /menu o el tinte

1. El jugador hace `/menu` o click derecho al tinte.
2. El plugin pregunta: ¿es Bedrock?
   - **Sí** → ejecuta `dm open flux_menu <nombre>` (menú de inventario).
   - **No** → abre el diálogo nativo de Paper.
3. Dentro de los botones de Java, si el jugador elige Kits/Warps también se redirige según el tipo de cliente.

---

## Personalizar menús Bedrock

Edita los `.yml` de DeluxeMenus con normalidad. Ejemplos:

- Añadir más warps en `warps.yml`.
- Poner tus kits reales en `kits.yml` con:
  ```yaml
  click_commands:
    - '[player] kit nombre_del_kit'
    - '[close]'
  ```
- Cambiar iconos, tamaños, colores, etc.

Los menús de Java se siguen editando en `plugins/SemianarquicoMenu/config.yml` (sección `menu`, `kits`, `warps`).

---

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/menu` | Abre el menú correcto según Java/Bedrock |
| `/menu reload` | Recarga config + detección Floodgate |
| `/kit` | Menú de kits (según cliente) |
| `/kit <nombre>` | Reclama un kit |
| `/kit create <nombre> <precio> [cat]` | Crea kit (admin) |
| `/warp` | Menú de warps (según cliente) |
| `/setwarp <nombre>` | Crea warp (admin) |

---

## Solución de problemas

**Bedrock sigue viendo el diálogo raro**
- Comprueba que el nombre empiece por `BD_` (o el prefijo que configuraste).
- Mira la consola al arrancar: debe decir `Floodgate: SI` o `NO (solo prefijo)`.
- Prueba manualmente: `/dm open flux_menu <nombre_del_jugador_bedrock>`.

**“Unknown command: dm”**
- DeluxeMenus no está cargado o el comando cambió. Usa el comando correcto de tu versión (a veces es `/deluxemenus open ...`).

**El menú de DeluxeMenus no se abre**
- Verifica que el menú esté registrado en `config.yml` de DeluxeMenus.
- Prueba `/dm list` para ver los menús cargados.

**Quieres forzar siempre DeluxeMenus (también para Java)**
- En `config.yml` del plugin puedes poner temporalmente un prefijo vacío o modificar el código, pero no es recomendable: los dialogs de Paper se ven mejor en Java.

---

## Estructura del ZIP

```
SemianarquicoMenu-v2.1/
├── pom.xml
├── src/main/java/.../SemianarquicoMenu.java
├── src/main/resources/
│   ├── plugin.yml
│   └── config.yml
├── DeluxeMenus/
│   ├── config_fragment.yml
│   └── gui_menus/
│       ├── flux_menu.yml   ← menú principal Bedrock
│       ├── kits.yml
│       ├── warps.yml
│       ├── rtp.yml
│       └── stats.yml
└── docs/
    └── INSTRUCCIONES.md    ← este archivo
```

---

## Resumen rápido

1. Compila o coloca el JAR 2.1.0.
2. Copia los 5 YAML de `DeluxeMenus/gui_menus/` a tu servidor.
3. Añade `flux_menu` en el config de DeluxeMenus.
4. Ajusta el prefijo `BD_` si es necesario.
5. Reinicia → prueba con una cuenta Java y una Bedrock.

Los jugadores Bedrock verán inventarios bonitos (DeluxeMenus).  
Los jugadores Java seguirán viendo los diálogos nativos limpios.
