package net.flux.menu;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.util.FormImage;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Formularios Bedrock (SimpleForm de Cumulus enviados con Floodgate).
 *
 * Cada boton se ve asi:
 *
 *     [ WARPS ]                 <- nombre, con su color
 *     Zonas de minas, PvP...    <- descripcion en la linea de abajo
 *
 * El formato sale de bedrock.formularios.formato-boton del config.yml.
 * Esta clase solo se carga si Floodgate esta instalado.
 */
final class BedrockForms {

    private static final String FORMATO_BOTON = "&f[ {nombre}&f ]\n{descripcion}";

    private final FluxMenu plugin;

    BedrockForms(FluxMenu plugin) {
        this.plugin = plugin;
        // Si falta Floodgate/Cumulus esto lanza NoClassDefFoundError y el plugin usa DeluxeMenus
        FloodgateApi.getInstance();
    }

    // ================================================================ utilidades

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    /** Convierte &c en codigos de color de Bedrock; quita la negrita si esta desactivada. */
    private String color(String texto) {
        if (texto == null) return "";
        if (!cfg().getBoolean("bedrock.formularios.negrita", false)) {
            texto = texto.replaceAll("(?i)&l", "");
        }
        return texto.replace('&', '\u00a7');
    }

    /** Boton con nombre arriba y descripcion debajo. */
    private String textoBoton(String formato, String nombre, String descripcion) {
        boolean hayDesc = descripcion != null && !descripcion.isBlank();
        if (!hayDesc) {
            return color(cfg().getString("bedrock.formularios.formato-boton-sin-descripcion", "&f[ {nombre}&f ]")
                    .replace("{nombre}", nombre == null ? "" : nombre));
        }
        return color(formato
                .replace("{nombre}", nombre == null ? "" : nombre)
                .replace("{descripcion}", descripcion));
    }

    private static void icono(SimpleForm.Builder form, String texto, String icono) {
        if (icono == null || icono.isBlank()) {
            form.button(texto);
        } else if (icono.startsWith("http://") || icono.startsWith("https://")) {
            form.button(texto, FormImage.Type.URL, icono);
        } else {
            form.button(texto, FormImage.Type.PATH, icono);
        }
    }

    private void enviar(Player p, SimpleForm.Builder form, List<Runnable> acciones) {
        form.validResultHandler(respuesta -> {
            int i = respuesta.clickedButtonId();
            if (i < 0 || i >= acciones.size()) return;
            Runnable accion = acciones.get(i);
            if (accion != null) Bukkit.getScheduler().runTask(plugin, accion);
        });
        if (!FloodgateApi.getInstance().sendForm(p.getUniqueId(), form.build())) {
            throw new IllegalStateException("Floodgate no pudo enviar el formulario a " + p.getName());
        }
    }

    // ================================================================ menu principal

    void principal(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.principal.titulo",
                        c.getString("menu.titulo", "MENU"))))
                .content(color(c.getString("bedrock.formularios.principal.descripcion",
                        c.getString("menu.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        ConfigurationSection botones = c.getConfigurationSection("menu.botones");
        if (botones != null) {
            for (String id : botones.getKeys(false)) {
                ConfigurationSection b = botones.getConfigurationSection(id);
                if (b == null) continue;
                String abre = b.getString("abre", "").toLowerCase(Locale.ROOT);
                String comando = b.getString("comando", "");
                icono(form, textoBoton(formato, b.getString("nombre", id), b.getString("descripcion")),
                        b.getString("icono", ""));
                acciones.add(() -> {
                    if (abre.equals("kits")) plugin.abrirMenuKits(p);
                    else if (abre.equals("warps")) plugin.abrirMenuWarps(p);
                    else plugin.ejecutar(p, comando);
                });
            }
        }
        enviar(p, form, acciones);
    }

    // ================================================================ kits

    void kits(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.formato-boton", FORMATO_BOTON);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.kits.titulo",
                        c.getString("kits.titulo", "KITS"))))
                .content(color(c.getString("bedrock.formularios.kits.descripcion",
                        c.getString("kits.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String cat : plugin.categorias()) {
            ConfigurationSection cs = c.getConfigurationSection("kits.categorias." + cat);
            if (cs == null) continue;
            icono(form, textoBoton(formato, cs.getString("nombre", cat), cs.getString("descripcion")),
                    cs.getString("icono", ""));
            acciones.add(() -> plugin.abrirCategoriaKits(p, cat));
        }
        icono(form, color(c.getString("kits.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.kits.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }

    void categoria(Player p, String cat) {
        FileConfiguration c = cfg();
        ConfigurationSection cs = c.getConfigurationSection("kits.categorias." + cat);
        if (cs == null) return;

        List<String> kits = plugin.nombresKits(cat);
        String formatoKit = c.getString("bedrock.formularios.categoria.formato-kit",
                "{kit}\n&aComprar &8- {precio}");
        String formatoGratis = c.getString("bedrock.formularios.categoria.formato-kit-gratis",
                "{kit}\n{precio}");
        boolean respetarNegrita = c.getBoolean("kits.respetar-negrita", true);

        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(cs.getString("titulo", cs.getString("nombre", cat))))
                .content(color(kits.isEmpty()
                        ? c.getString("bedrock.formularios.categoria.descripcion-vacia",
                                "&7Todavia no hay kits en esta categoria.")
                        : c.getString("bedrock.formularios.categoria.descripcion",
                                "&fHaz click en un kit para obtenerlo:")));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : kits) {
            String desc = plugin.descripcionKit(nombre);
            double valor = plugin.precioKit(nombre);
            String precio = plugin.precioTxt(valor);
            String plantilla = valor <= 0 ? formatoGratis : formatoKit;
            // el nombre lleva SU color (y negrita); se pasa ya convertido para que color() no le quite la &l
            String kitTxt = plugin.nombreKitTxt(nombre);
            if (!respetarNegrita) kitTxt = kitTxt.replaceAll("(?i)&l", "");
            kitTxt = kitTxt.replace('&', '\u00a7');
            icono(form, color(plantilla
                            .replace("{kit}", kitTxt)
                            .replace("{precio}", precio)
                            .replace("{descripcion}", desc)),
                    plugin.iconoKit(nombre));
            acciones.add(() -> plugin.reclamarKit(p, nombre));
        }
        icono(form, color(c.getString("bedrock.formularios.categoria.volver", "&7Volver a las categorias")),
                c.getString("bedrock.formularios.categoria.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuKits(p));
        enviar(p, form, acciones);
    }

    // ================================================================ warps

    void warps(Player p) {
        FileConfiguration c = cfg();
        String formato = c.getString("bedrock.formularios.warps.formato",
                "&f[ &b{nombre}&f ]\n{descripcion}");
        String porDefecto = c.getString("warps.descripcion-por-defecto", "");

        List<String> nombres = plugin.nombresWarps();
        SimpleForm.Builder form = SimpleForm.builder()
                .title(color(c.getString("bedrock.formularios.warps.titulo",
                        c.getString("warps.titulo", "WARPS"))))
                .content(color(nombres.isEmpty()
                        ? c.getString("warps.sin-warps", "&7Todavia no hay warps creados.")
                        : c.getString("bedrock.formularios.warps.descripcion",
                                c.getString("warps.descripcion", ""))));

        List<Runnable> acciones = new ArrayList<>();
        for (String nombre : nombres) {
            String desc = plugin.descripcionWarp(nombre);
            if (desc.isBlank()) desc = porDefecto;
            icono(form, textoBoton(formato, nombre.toUpperCase(Locale.ROOT), desc),
                    c.getString("bedrock.formularios.warps.icono", "textures/items/ender_pearl"));
            acciones.add(() -> plugin.irAWarp(p, nombre));
        }
        icono(form, color(c.getString("warps.volver", "&7Volver al Menu Principal")),
                c.getString("bedrock.formularios.warps.icono-volver", "textures/items/arrow"));
        acciones.add(() -> plugin.abrirMenuPrincipal(p));
        enviar(p, form, acciones);
    }
}
