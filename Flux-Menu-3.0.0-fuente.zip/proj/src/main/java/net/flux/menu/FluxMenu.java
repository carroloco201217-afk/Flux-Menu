package net.flux.menu;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class FluxMenu extends JavaPlugin implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private NamespacedKey tinteKey;
    private NamespacedKey tinteKeyViejo; // item de las versiones anteriores (SemianarquicoMenu)
    private File kitsFile;
    private File warpsFile;
    private YamlConfiguration kitsCfg;
    private YamlConfiguration warpsCfg;

    private boolean floodgatePresent;
    private Object floodgateApi; // org.geysermc.floodgate.api.FloodgateApi
    private BedrockForms bedrockForms; // formularios Bedrock (solo si hay Floodgate)

    // ================================================================ arranque

    @Override
    public void onEnable() {
        saveDefaultConfig();
        tinteKey = new NamespacedKey(this, "tinte_menu");
        tinteKeyViejo = NamespacedKey.fromString("semianarquicomenu:tinte_menu");
        migrarDatosViejos();
        cargarDatos();
        detectarFloodgate();
        getServer().getPluginManager().registerEvents(this, this);
        iniciarRevisionTinte();
        getLogger().info("Flux - Menu " + getPluginMeta().getVersion() + " activo. Floodgate: "
                + (floodgatePresent ? "SI" : "NO (solo prefijo)"));
    }

    /** Copia kits.yml y warps.yml de la carpeta vieja (plugins/SemianarquicoMenu) la primera vez. */
    private void migrarDatosViejos() {
        if (!getConfig().getBoolean("general.migrar-datos-antiguos", true)) return;
        File viejo = new File(getDataFolder().getParentFile(), "SemianarquicoMenu");
        if (!viejo.isDirectory()) return;
        getDataFolder().mkdirs();
        for (String nombre : new String[]{"kits.yml", "warps.yml"}) {
            File origen = new File(viejo, nombre);
            File destino = new File(getDataFolder(), nombre);
            if (!origen.isFile() || destino.exists()) continue;
            try {
                java.nio.file.Files.copy(origen.toPath(), destino.toPath());
                getLogger().info("Datos copiados de la version anterior: " + nombre);
            } catch (IOException e) {
                getLogger().warning("No se pudo copiar " + nombre + ": " + e.getMessage());
            }
        }
    }

    private void detectarFloodgate() {
        floodgatePresent = false;
        floodgateApi = null;
        if (!getConfig().getBoolean("bedrock.usar-floodgate", true)) return;
        if (getServer().getPluginManager().getPlugin("floodgate") == null) return;
        try {
            Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Method getInstance = apiClass.getMethod("getInstance");
            floodgateApi = getInstance.invoke(null);
            floodgatePresent = true;
        } catch (Throwable t) {
            getLogger().warning("Floodgate detectado pero no se pudo cargar la API: " + t.getMessage());
        }
        iniciarFormularios();
    }

    /** Prepara los formularios Bedrock (botones con icono, nombre arriba y descripcion abajo). */
    private void iniciarFormularios() {
        bedrockForms = null;
        if (!floodgatePresent) return;
        if (!getConfig().getBoolean("bedrock.formularios.activar", true)) return;
        try {
            bedrockForms = new BedrockForms(this);
        } catch (Throwable t) {
            getLogger().warning("No se pudieron preparar los formularios Bedrock (se usara DeluxeMenus): " + t);
        }
    }

    /** Ejecuta un formulario Bedrock; devuelve false si no se pudo y hay que usar el menu de respaldo. */
    private boolean formulario(Runnable envio) {
        if (bedrockForms == null) return false;
        try {
            envio.run();
            return true;
        } catch (Throwable t) {
            getLogger().warning("Fallo al enviar un formulario Bedrock, se usa el menu de respaldo: " + t);
            return false;
        }
    }

    private void cargarDatos() {
        kitsFile = new File(getDataFolder(), "kits.yml");
        warpsFile = new File(getDataFolder(), "warps.yml");
        kitsCfg = YamlConfiguration.loadConfiguration(kitsFile);
        warpsCfg = YamlConfiguration.loadConfiguration(warpsFile);
    }

    private void guardar(YamlConfiguration cfg, File archivo) {
        try {
            cfg.save(archivo);
        } catch (IOException e) {
            getLogger().severe("No se pudo guardar " + archivo.getName() + ": " + e.getMessage());
        }
    }

    // ================================================================ deteccion Bedrock

    /**
     * True si el jugador es Bedrock (Floodgate o prefijo configurado).
     */
    public boolean esBedrock(Player p) {
        if (floodgatePresent && floodgateApi != null) {
            try {
                Method isFloodgatePlayer = floodgateApi.getClass().getMethod("isFloodgatePlayer", java.util.UUID.class);
                Object result = isFloodgatePlayer.invoke(floodgateApi, p.getUniqueId());
                if (result instanceof Boolean b && b) return true;
            } catch (Throwable ignored) {
            }
        }
        String name = p.getName();
        List<String> prefijos = getConfig().getStringList("bedrock.prefijos");
        if (prefijos == null || prefijos.isEmpty()) {
            prefijos = List.of("BD_", "BD.");
        }
        for (String pref : prefijos) {
            if (name.regionMatches(true, 0, pref, 0, pref.length())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Abre un menu de DeluxeMenus para un jugador Bedrock.
     * Si DeluxeMenus no esta o falla, hace fallback al dialogo Java.
     */
    private void abrirMenuBedrock(Player p, String tipo) {
        boolean enviado = switch (tipo) {
            case "kits" -> formulario(() -> bedrockForms.kits(p));
            case "warps" -> formulario(() -> bedrockForms.warps(p));
            default -> formulario(() -> bedrockForms.principal(p));
        };
        if (enviado) return;
        String cmd = getConfig().getString("bedrock.menus." + tipo, "");
        if (cmd == null || cmd.isBlank()) {
            // fallback
            switch (tipo) {
                case "kits" -> abrirMenuKitsJava(p);
                case "warps" -> abrirMenuWarpsJava(p);
                default -> abrirMenuPrincipalJava(p);
            }
            return;
        }
        cmd = cmd.replace("{jugador}", p.getName());
        // Ejecutar como consola para que dm open funcione bien
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    // ================================================================ utilidades

    private static Component c(String texto) {
        return LEGACY.deserialize(texto == null ? "" : texto)
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    private Component msg(String clave, String... pares) {
        String t = getConfig().getString("mensajes." + clave, "&c[falta el mensaje " + clave + "]");
        for (int i = 0; i + 1 < pares.length; i += 2) {
            t = t.replace("{" + pares[i] + "}", pares[i + 1]);
        }
        return c(t);
    }

    private static String bonito(String material) {
        return material.toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    /** Precio listo para mostrar: 1.0k, 1.5M, 2.0B ... (todo configurable en la seccion "precio"). */
    String precioTxt(double precio) {
        if (precio <= 0) return getConfig().getString("precio.gratis", "&aGratis");
        return getConfig().getString("precio.formato", "&e{moneda}{cantidad}")
                .replace("{moneda}", getConfig().getString("moneda", ""))
                .replace("{cantidad}", cantidadCorta(precio));
    }

    private List<String> sufijosPrecio() {
        List<String> s = getConfig().getStringList("precio.sufijos");
        return s.isEmpty() ? List.of("k", "M", "B", "T") : s;
    }

    private String cantidadCorta(double v) {
        if (v < 1000 || v < getConfig().getDouble("precio.abreviar-desde", 1000)) {
            return String.format(Locale.US, "%,.0f", v);
        }
        List<String> suf = sufijosPrecio();
        String formato = "%." + Math.max(0, Math.min(4, getConfig().getInt("precio.decimales", 1))) + "f";
        double x = v;
        int idx = -1;
        while (x >= 1000 && idx < suf.size() - 1) {
            x /= 1000;
            idx++;
        }
        String num = String.format(Locale.US, formato, x);
        // 999.99k redondea a 1000.0k -> mejor 1.0M
        if (Double.parseDouble(num) >= 1000 && idx < suf.size() - 1) {
            x /= 1000;
            idx++;
            num = String.format(Locale.US, formato, x);
        }
        return num + suf.get(Math.max(0, idx));
    }

    /** Lee un precio escrito como 5000, 1k, 2.5M, 1B ... Lanza NumberFormatException si no es valido. */
    private double leerPrecio(String texto) {
        String t = texto.trim().replace(",", "");
        double mult = 1;
        List<String> suf = sufijosPrecio();
        for (int i = 0; i < suf.size(); i++) {
            String s = suf.get(i);
            if (s == null || s.isBlank()) continue;
            if (t.toLowerCase(Locale.ROOT).endsWith(s.toLowerCase(Locale.ROOT))) {
                t = t.substring(0, t.length() - s.length());
                mult = Math.pow(1000, i + 1);
                break;
            }
        }
        if (!t.matches("[0-9]+(\\.[0-9]+)?|\\.[0-9]+")) throw new NumberFormatException(texto);
        return Double.parseDouble(t) * mult;
    }

    // ---------------------------------------------------------------- permisos configurables

    private String permiso(String clave, String porDefecto) {
        return getConfig().getString("permisos." + clave, porDefecto);
    }

    /** Permiso de administracion: si lo dejan vacio en el config, solo pueden los OP. */
    private boolean esAdmin(CommandSender s, String clave, String porDefecto) {
        String perm = permiso(clave, porDefecto);
        if (perm == null || perm.isBlank()) return s.isOp();
        return s.hasPermission(perm);
    }

    private boolean adminKits(CommandSender s) {
        return esAdmin(s, "kits-admin", "semianarquico.kits.admin");
    }

    private boolean adminWarps(CommandSender s) {
        return esAdmin(s, "warp-admin", "semianarquico.warp.admin");
    }

    // ---------------------------------------------------------------- solo Bedrock

    /** true si esta parte del sistema esta bloqueada para este jugador (es Java y solo-bedrock esta activo). */
    private boolean bloqueadoJava(Player p, String parte) {
        if (!getConfig().getBoolean("solo-bedrock.activar", true)) return false;
        if (!getConfig().getBoolean("solo-bedrock.aplica-a." + parte, true)) return false;
        return !esBedrock(p);
    }

    private static final java.util.Set<String> COMANDOS_PROPIOS = java.util.Set.of(
            "menu", "menuprincipal", "kit", "kits", "warp", "warps", "setwarp", "delwarp", "warpdesc");

    /**
     * Un jugador Java no puede usar esta parte: si hay un comando alternativo configurado
     * (por ejemplo el /kit de PlayerKits2) se ejecuta, y si no, recibe el mensaje.
     */
    private void rechazarJava(Player p, String clave, String args) {
        String plantilla = getConfig().getString("solo-bedrock.java-redirige." + clave, "");
        if (plantilla != null && !plantilla.isBlank()) {
            String primero = plantilla.trim().split("\\s+")[0].toLowerCase(Locale.ROOT);
            boolean propio = COMANDOS_PROPIOS.contains(primero) || primero.startsWith("flux:");
            if (!propio && Bukkit.getCommandMap().getCommand(primero) != null) {
                String extra = args == null ? "" : args.trim();
                String base = plantilla.replace("{jugador}", p.getName());
                String cmd = base.contains("{args}")
                        ? base.replace("{args}", extra)
                        : (extra.isEmpty() ? base : base + " " + extra);
                p.performCommand(cmd.trim());
                return;
            }
        }
        p.sendMessage(msg("solo-bedrock"));
    }

    private Economy economia() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return null;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }

    private Player soloJugador(CommandSender sender) {
        if (sender instanceof Player p) return p;
        sender.sendMessage(getConfig().getString("mensajes.solo-jugadores", "Solo jugadores."));
        return null;
    }

    private static String unir(String[] args, int desde) {
        StringBuilder sb = new StringBuilder();
        for (int i = desde; i < args.length; i++) {
            if (i > desde) sb.append(' ');
            sb.append(args[i]);
        }
        return sb.toString();
    }

    List<String> categorias() {
        ConfigurationSection s = getConfig().getConfigurationSection("kits.categorias");
        return s == null ? new ArrayList<>() : new ArrayList<>(s.getKeys(false));
    }

    // ================================================================ tinte

    private ItemStack crearTinte() {
        ConfigurationSection s = getConfig().getConfigurationSection("tinte");
        Material mat = Material.matchMaterial(s.getString("material", "YELLOW_DYE"));
        if (mat == null) mat = Material.YELLOW_DYE;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(c(s.getString("nombre")));
        List<Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(c(l));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(tinteKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean esTinte(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        var datos = item.getItemMeta().getPersistentDataContainer();
        return datos.has(tinteKey, PersistentDataType.BYTE)
                || (tinteKeyViejo != null && datos.has(tinteKeyViejo, PersistentDataType.BYTE));
    }

    private boolean tinteOpcion(String clave) {
        return getConfig().getBoolean("tinte." + clave, true);
    }

    private boolean tieneTinte(Player p) {
        if (esTinte(p.getItemOnCursor())) return true;
        for (ItemStack it : p.getInventory().getContents()) {
            if (esTinte(it)) return true;
        }
        return false;
    }

    /** Le da el item del menu al jugador si no lo tiene. */
    private void asegurarTinte(Player p) {
        if (bloqueadoJava(p, "menu")) return; // solo-bedrock: a los de Java no se les da
        if (tieneTinte(p)) return;
        int slot = Math.max(0, Math.min(8, getConfig().getInt("tinte.slot", 8)));
        ItemStack previo = p.getInventory().getItem(slot);
        p.getInventory().setItem(slot, crearTinte());
        if (previo != null && !previo.getType().isAir()) {
            p.getInventory().addItem(previo).values()
                    .forEach(resto -> p.getWorld().dropItemNaturally(p.getLocation(), resto));
        }
    }

    private void iniciarRevisionTinte() {
        int seg = getConfig().getInt("tinte.revisar-cada-segundos", 10);
        if (seg <= 0) return;
        long ticks = 20L * seg;
        getServer().getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.isDead()) asegurarTinte(p);
            }
        }, ticks, ticks);
    }

    @EventHandler
    public void alEntrar(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPlayedBefore() || tinteOpcion("entregar-al-entrar")) {
            asegurarTinte(p);
        }
    }

    /** Al morir el item no cae al suelo (no se pierde ni lo puede recoger otro). */
    @EventHandler
    public void alMorir(PlayerDeathEvent e) {
        if (!tinteOpcion("conservar-al-morir")) return;
        e.getDrops().removeIf(this::esTinte);
    }

    @EventHandler
    public void alReaparecer(PlayerRespawnEvent e) {
        if (!tinteOpcion("entregar-al-reaparecer")) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> {
            if (p.isOnline()) asegurarTinte(p);
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void alSoltar(PlayerDropItemEvent e) {
        if (!tinteOpcion("bloquear-soltar")) return;
        if (esTinte(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void alClickInventario(InventoryClickEvent e) {
        if (!tinteOpcion("bloquear-mover")) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        Inventory superior = e.getView().getTopInventory();
        Inventory clicado = e.getClickedInventory();
        boolean clickEnSuperior = clicado != null && clicado.equals(superior);
        boolean ventanaExterna = superior.getType() != InventoryType.CRAFTING;
        ClickType tipo = e.getClick();

        // Q / Ctrl+Q sobre el item
        if (esTinte(e.getCurrentItem()) && (tipo == ClickType.DROP || tipo == ClickType.CONTROL_DROP)) {
            e.setCancelled(true);
            return;
        }
        // Shift+click desde tu inventario hacia un cofre, horno, etc.
        if (ventanaExterna && !clickEnSuperior && esTinte(e.getCurrentItem())
                && (tipo == ClickType.SHIFT_LEFT || tipo == ClickType.SHIFT_RIGHT)) {
            e.setCancelled(true);
            return;
        }
        if (!clickEnSuperior) return;
        // Dejar el item (en el cursor) dentro del cofre / tabla de crafteo
        if (esTinte(e.getCursor())) {
            e.setCancelled(true);
            return;
        }
        // Tecla numerica o F con el item en la hotbar / mano secundaria
        if (tipo == ClickType.NUMBER_KEY) {
            int boton = e.getHotbarButton();
            if (boton >= 0 && esTinte(p.getInventory().getItem(boton))) e.setCancelled(true);
        } else if (tipo == ClickType.SWAP_OFFHAND) {
            if (esTinte(p.getInventory().getItemInOffHand())) e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void alArrastrar(InventoryDragEvent e) {
        if (!tinteOpcion("bloquear-mover")) return;
        if (!esTinte(e.getOldCursor())) return;
        int tam = e.getView().getTopInventory().getSize();
        for (int raw : e.getRawSlots()) {
            if (raw < tam) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void alInteractuar(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!esTinte(e.getItem())) return;
        e.setCancelled(true);
        abrirMenuPrincipal(e.getPlayer());
    }

    // ================================================================ dialogos (base) - solo Java

    private ActionButton boton(Component etiqueta, Component tooltip, Runnable accion) {
        int ancho = Math.max(100, Math.min(1024, getConfig().getInt("ancho-botones", 320)));
        return ActionButton.create(
                etiqueta,
                tooltip,
                ancho,
                DialogAction.customClick((view, audience) -> {
                    if (audience instanceof Player) {
                        Bukkit.getScheduler().runTask(this, accion);
                    }
                }, ClickCallback.Options.builder().build())
        );
    }

    private Component etiqueta(String nombre, String descripcion) {
        String formato = getConfig().getString("dialogos.formato-boton", "{nombre}");
        boolean hayDesc = descripcion != null && !descripcion.isBlank();
        String t = formato
                .replace("{nombre}", nombre == null ? "" : nombre)
                .replace("{descripcion}", hayDesc ? descripcion : "");
        // sin descripcion no dejamos separadores sueltos como " - "
        if (!hayDesc) t = nombre == null ? "" : nombre;
        return c(t);
    }

    private Component tooltipDe(String descripcion) {
        return (descripcion == null || descripcion.isBlank()) ? null : c(descripcion);
    }

    private void mostrar(Player p, String titulo, String descripcion, List<ActionButton> botones) {
        Dialog dialogo = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(c(titulo))
                        .canCloseWithEscape(true)
                        .body(List.of(DialogBody.plainMessage(c(descripcion))))
                        .build())
                .type(DialogType.multiAction(botones, null, 1)));
        p.showDialog(dialogo);
    }

    void ejecutar(Player p, String comando) {
        if (comando == null || comando.isBlank()) return;
        String cmd = comando
                .replace("{mundo}", getConfig().getString("rtp.mundo", "survival"))
                .replace("{jugador}", p.getName());
        p.performCommand(cmd);
    }

    // ================================================================ menu principal (punto de entrada)

    public void abrirMenuPrincipal(Player p) {
        if (bloqueadoJava(p, "menu")) {
            rechazarJava(p, "menu", "");
            return;
        }
        if (esBedrock(p)) {
            abrirMenuBedrock(p, "principal");
        } else {
            abrirMenuPrincipalJava(p);
        }
    }

    private void abrirMenuPrincipalJava(Player p) {
        ConfigurationSection m = getConfig().getConfigurationSection("menu");
        ConfigurationSection botones = m.getConfigurationSection("botones");

        List<ActionButton> acciones = new ArrayList<>();
        for (String id : botones.getKeys(false)) {
            ConfigurationSection b = botones.getConfigurationSection(id);
            String abre = b.getString("abre", "").toLowerCase(Locale.ROOT);
            acciones.add(boton(
                    etiqueta(b.getString("nombre"), b.getString("descripcion")),
                    tooltipDe(b.getString("descripcion")),
                    () -> {
                        if (abre.equals("kits")) abrirMenuKits(p);
                        else if (abre.equals("warps")) abrirMenuWarps(p);
                        else ejecutar(p, b.getString("comando"));
                    }));
        }
        mostrar(p, m.getString("titulo"), m.getString("descripcion"), acciones);
    }

    // ================================================================ menu de kits

    public void abrirMenuKits(Player p) {
        if (bloqueadoJava(p, "kits")) {
            rechazarJava(p, "kit", "");
            return;
        }
        if (esBedrock(p)) {
            abrirMenuBedrock(p, "kits");
        } else {
            abrirMenuKitsJava(p);
        }
    }

    private void abrirMenuKitsJava(Player p) {
        ConfigurationSection k = getConfig().getConfigurationSection("kits");
        List<ActionButton> acciones = new ArrayList<>();
        for (String cat : categorias()) {
            ConfigurationSection cs = k.getConfigurationSection("categorias." + cat);
            acciones.add(boton(
                    etiqueta(cs.getString("nombre"), cs.getString("descripcion")),
                    tooltipDe(cs.getString("descripcion")),
                    () -> abrirCategoriaKits(p, cat)));
        }
        acciones.add(boton(c(k.getString("volver")), null, () -> abrirMenuPrincipal(p)));
        mostrar(p, k.getString("titulo"), k.getString("descripcion"), acciones);
    }

    public void abrirCategoriaKits(Player p, String cat) {
        if (bloqueadoJava(p, "kits")) {
            rechazarJava(p, "kit", "");
            return;
        }
        if (esBedrock(p) && formulario(() -> bedrockForms.categoria(p, cat))) return;
        ConfigurationSection cs = getConfig().getConfigurationSection("kits.categorias." + cat);
        if (cs == null) return;

        List<String> kits = nombresKits(cat);
        List<ActionButton> acciones = new ArrayList<>();
        for (String nombre : kits) {
            String base = "kits." + nombre;
            String precio = precioTxt(kitsCfg.getDouble(base + ".precio", 0));
            String desc = kitsCfg.getString(base + ".descripcion", "");
            String texto = getConfig().getString("dialogos.formato-kit", "{kit} &8- {precio}")
                    .replace("{kit}", nombreKitTxt(nombre))
                    .replace("{precio}", precio)
                    .replace("{descripcion}", desc);
            acciones.add(boton(
                    etiqueta(texto, desc),
                    tooltipKit(nombre),
                    () -> reclamarKit(p, nombre)));
        }
        acciones.add(boton(c(getConfig().getString("kits.volver")), null, () -> abrirMenuKits(p)));

        String texto = kits.isEmpty()
                ? getConfig().getString("dialogos.categoria.sin-kits", "&7Todavia no hay kits en esta categoria.")
                : getConfig().getString("dialogos.categoria.con-kits", "&fHaz click en un kit para obtenerlo:");
        mostrar(p, cs.getString("titulo", cs.getString("nombre")), texto, acciones);
    }

    String descripcionKit(String nombre) {
        return kitsCfg.getString("kits." + nombre + ".descripcion", "");
    }

    double precioKit(String nombre) {
        return kitsCfg.getDouble("kits." + nombre + ".precio", 0);
    }

    /** Codigos de color del kit (por defecto los de kits.color-por-defecto, p. ej. &e&l). */
    String colorKit(String nombre) {
        String c = kitsCfg.getString("kits." + nombre + ".color", "");
        if (c == null || c.isBlank()) c = getConfig().getString("kits.color-por-defecto", "&e&l");
        return c;
    }

    /** Nombre del kit ya con su color; termina en &r para que el color/negrita no se pase al resto. */
    String nombreKitTxt(String nombre) {
        String n = getConfig().getBoolean("kits.nombre-en-mayusculas", true)
                ? nombre.toUpperCase(Locale.ROOT) : nombre;
        return colorKit(nombre) + n + "&r";
    }

    /** Icono de la categoria para sus kits: icono-kit de la categoria, o el icono de la categoria. */
    String iconoCategoriaKit(String cat) {
        String ic = getConfig().getString("kits.categorias." + cat + ".icono-kit", "");
        if (ic == null || ic.isBlank()) ic = getConfig().getString("kits.categorias." + cat + ".icono", "");
        if (ic == null || ic.isBlank()) ic = getConfig().getString("bedrock.formularios.categoria.icono-kit", "");
        return ic == null ? "" : ic;
    }

    /** Textura del kit: la suya si se la pusieron con /kit icono, y si no la de su categoria. */
    String iconoKit(String nombre) {
        String ic = kitsCfg.getString("kits." + nombre + ".icono", "");
        if (ic != null && !ic.isBlank()) return ic;
        String cat = kitsCfg.getString("kits." + nombre + ".categoria",
                getConfig().getString("kits.categoria-por-defecto", "dinero"));
        return iconoCategoriaKit(cat);
    }

    String descripcionWarp(String nombre) {
        return warpsCfg.getString("warps." + nombre + ".descripcion", "");
    }

    List<String> nombresKits(String categoria) {
        List<String> r = new ArrayList<>();
        ConfigurationSection s = kitsCfg.getConfigurationSection("kits");
        if (s == null) return r;
        // una categoria puede mostrar tambien los kits de otras (kits.categorias.<cat>.mostrar-tambien)
        List<String> cats = new ArrayList<>();
        if (categoria != null) {
            cats.add(categoria.toLowerCase(Locale.ROOT));
            for (String extra : getConfig().getStringList("kits.categorias." + categoria + ".mostrar-tambien")) {
                cats.add(extra.toLowerCase(Locale.ROOT));
            }
        }
        for (String n : s.getKeys(false)) {
            String cat = s.getString(n + ".categoria", getConfig().getString("kits.categoria-por-defecto", "dinero"));
            if (categoria == null || cats.contains(cat.toLowerCase(Locale.ROOT))) r.add(n);
        }
        Collections.sort(r);
        return r;
    }

    private Component tooltipKit(String nombre) {
        String base = "kits." + nombre;
        Component t = Component.empty();
        String desc = kitsCfg.getString(base + ".descripcion", "");
        if (!desc.isBlank()) t = t.append(c(desc)).append(Component.newline());
        t = t.append(c(getConfig().getString("dialogos.tooltip-kit.titulo", "&7Contiene:")));
        List<?> lista = kitsCfg.getList(base + ".items");
        int n = 0;
        int maximo = Math.max(1, getConfig().getInt("dialogos.tooltip-kit.maximo-items", 8));
        if (lista != null) {
            for (Object o : lista) {
                if (!(o instanceof ItemStack it)) continue;
                if (n++ >= maximo) {
                    t = t.append(Component.newline())
                            .append(c(getConfig().getString("dialogos.tooltip-kit.mas", "&8...")));
                    break;
                }
                t = t.append(Component.newline())
                        .append(c(getConfig().getString("dialogos.tooltip-kit.item", "&f{cantidad}x &7{item}")
                                .replace("{cantidad}", String.valueOf(it.getAmount()))
                                .replace("{item}", bonito(it.getType().name()))));
            }
        }
        return t;
    }

    // ================================================================ logica de kits

    void reclamarKit(Player p, String nombre) {
        if (bloqueadoJava(p, "kits")) {
            rechazarJava(p, "kit", nombre);
            return;
        }
        String key = nombre.toLowerCase(Locale.ROOT);
        String base = "kits." + key;
        if (!kitsCfg.contains(base)) {
            p.sendMessage(msg("kit-no-existe", "kit", nombre));
            return;
        }

        String cat = kitsCfg.getString(base + ".categoria", "dinero");
        String permiso = getConfig().getString("kits.categorias." + cat + ".permiso", "");
        if (!permiso.isEmpty()
                && !p.hasPermission(permiso)
                && !p.hasPermission(permiso("kit-individual", "semianarquico.kit.") + key)
                && !adminKits(p)) {
            p.sendMessage(msg("kit-sin-permiso", "kit", key));
            return;
        }

        double precio = kitsCfg.getDouble(base + ".precio", 0);
        if (precio > 0) {
            Economy eco = economia();
            if (eco == null) {
                p.sendMessage(msg("sin-economia"));
                return;
            }
            if (!eco.has(p, precio) || !eco.withdrawPlayer(p, precio).transactionSuccess()) {
                p.sendMessage(msg("sin-dinero", "precio", precioTxt(precio)));
                return;
            }
        }

        List<?> lista = kitsCfg.getList(base + ".items");
        if (lista != null) {
            for (Object o : lista) {
                if (!(o instanceof ItemStack it)) continue;
                p.getInventory().addItem(it.clone()).values()
                        .forEach(resto -> p.getWorld().dropItemNaturally(p.getLocation(), resto));
            }
        }
        p.sendMessage(msg("kit-recibido", "kit", key));
    }

    private void crearKit(Player p, String nombre, double precio, String categoria) {
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack it : p.getInventory().getContents()) {
            if (it != null && !it.getType().isAir()) items.add(it.clone());
        }
        if (items.isEmpty()) {
            p.sendMessage(msg("kit-vacio"));
            return;
        }
        String base = "kits." + nombre;
        kitsCfg.set(base + ".precio", precio);
        kitsCfg.set(base + ".categoria", categoria);
        kitsCfg.set(base + ".color", getConfig().getString("kits.color-por-defecto", "&e&l"));
        kitsCfg.set(base + ".items", items);
        guardar(kitsCfg, kitsFile);
        p.sendMessage(msg("kit-creado", "kit", nombre, "precio", precioTxt(precio), "categoria", categoria));
    }

    private boolean cmdKit(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Player p = soloJugador(sender);
            if (p != null) abrirMenuKits(p);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        boolean admin = adminKits(sender);

        if (sub.equals("create") || sub.equals("crear")) {
            if (!admin) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            Player p = soloJugador(sender);
            if (p == null) return true;
            if (args.length < 3) {
                p.sendMessage(msg("uso-kit-create"));
                return true;
            }
            String nombre = args[1].toLowerCase(Locale.ROOT);
            if (!nombre.matches("[a-z0-9_-]{1,32}")) {
                p.sendMessage(msg("nombre-invalido"));
                return true;
            }
            double precio;
            try {
                precio = leerPrecio(args[2]);
            } catch (NumberFormatException ex) {
                p.sendMessage(msg("precio-invalido"));
                return true;
            }
            if (precio < 0) {
                p.sendMessage(msg("precio-invalido"));
                return true;
            }
            String cat = args.length >= 4 ? args[3].toLowerCase(Locale.ROOT)
                    : getConfig().getString("kits.categoria-por-defecto", "dinero");
            if (!categorias().contains(cat)) {
                p.sendMessage(msg("categoria-invalida", "lista", String.join(", ", categorias())));
                return true;
            }
            crearKit(p, nombre, precio, cat);
            return true;
        }

        if (sub.equals("delete") || sub.equals("borrar") || sub.equals("eliminar")) {
            if (!admin) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(msg("uso-kit-delete"));
                return true;
            }
            String nombre = args[1].toLowerCase(Locale.ROOT);
            if (!kitsCfg.contains("kits." + nombre)) {
                sender.sendMessage(msg("kit-no-existe", "kit", nombre));
                return true;
            }
            kitsCfg.set("kits." + nombre, null);
            guardar(kitsCfg, kitsFile);
            sender.sendMessage(msg("kit-borrado", "kit", nombre));
            return true;
        }

        if (sub.equals("desc")) {
            if (!admin) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(msg("uso-kit-desc"));
                return true;
            }
            String nombre = args[1].toLowerCase(Locale.ROOT);
            if (!kitsCfg.contains("kits." + nombre)) {
                sender.sendMessage(msg("kit-no-existe", "kit", nombre));
                return true;
            }
            kitsCfg.set("kits." + nombre + ".descripcion", unir(args, 2));
            guardar(kitsCfg, kitsFile);
            sender.sendMessage(msg("kit-desc", "kit", nombre));
            return true;
        }

        if (sub.equals("color")) {
            if (!admin) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(msg("uso-kit-color"));
                return true;
            }
            String nombre = args[1].toLowerCase(Locale.ROOT);
            if (!kitsCfg.contains("kits." + nombre)) {
                sender.sendMessage(msg("kit-no-existe", "kit", nombre));
                return true;
            }
            String codigos = unir(args, 2).replace(" ", "");
            kitsCfg.set("kits." + nombre + ".color", codigos);
            guardar(kitsCfg, kitsFile);
            sender.sendMessage(msg("kit-color", "kit", nombre, "color", codigos));
            return true;
        }

        if (sub.equals("icono")) {
            if (!admin) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(msg("uso-kit-icono"));
                return true;
            }
            String nombre = args[1].toLowerCase(Locale.ROOT);
            if (!kitsCfg.contains("kits." + nombre)) {
                sender.sendMessage(msg("kit-no-existe", "kit", nombre));
                return true;
            }
            String valor = args[2];
            boolean auto = valor.equalsIgnoreCase("auto");
            kitsCfg.set("kits." + nombre + ".icono", auto ? null : valor);
            guardar(kitsCfg, kitsFile);
            sender.sendMessage(msg("kit-icono", "kit", nombre, "icono", auto ? iconoKit(nombre) : valor));
            return true;
        }

        if (sub.equals("list") || sub.equals("lista")) {
            sender.sendMessage(msg("kit-lista", "lista", String.join(", ", nombresKits(null))));
            return true;
        }

        Player p = soloJugador(sender);
        if (p != null) reclamarKit(p, args[0]);
        return true;
    }

    // ================================================================ warps

    List<String> nombresWarps() {
        List<String> r = new ArrayList<>();
        ConfigurationSection s = warpsCfg.getConfigurationSection("warps");
        if (s != null) r.addAll(s.getKeys(false));
        Collections.sort(r);
        return r;
    }

    public void abrirMenuWarps(Player p) {
        if (bloqueadoJava(p, "warps-menu")) {
            rechazarJava(p, "warp", "");
            return;
        }
        if (esBedrock(p)) {
            abrirMenuBedrock(p, "warps");
        } else {
            abrirMenuWarpsJava(p);
        }
    }

    private void abrirMenuWarpsJava(Player p) {
        ConfigurationSection w = getConfig().getConfigurationSection("warps");
        List<String> nombres = nombresWarps();
        List<ActionButton> acciones = new ArrayList<>();
        for (String nombre : nombres) {
            String desc = warpsCfg.getString("warps." + nombre + ".descripcion", "");
            if (desc.isBlank()) desc = w.getString("descripcion-por-defecto", "");
            acciones.add(boton(
                    etiqueta(getConfig().getString("dialogos.formato-warp", "&b&l{warp}")
                            .replace("{warp}", nombre.toUpperCase(Locale.ROOT)), desc),
                    tooltipDe(desc),
                    () -> irAWarp(p, nombre)));
        }
        acciones.add(boton(c(w.getString("volver")), null, () -> abrirMenuPrincipal(p)));
        String texto = nombres.isEmpty() ? w.getString("sin-warps") : w.getString("descripcion");
        mostrar(p, w.getString("titulo"), texto, acciones);
    }

    void irAWarp(Player p, String nombre) {
        if (bloqueadoJava(p, "warps-ir")) {
            rechazarJava(p, "warp", nombre);
            return;
        }
        String key = nombre.toLowerCase(Locale.ROOT);
        String base = "warps." + key;
        if (!warpsCfg.contains(base)) {
            p.sendMessage(msg("warp-no-existe", "warp", nombre));
            return;
        }
        Location loc = warpsCfg.getLocation(base + ".ubicacion");
        if (loc == null || loc.getWorld() == null) {
            p.sendMessage(msg("mundo-no-cargado"));
            return;
        }
        p.teleport(loc);
        p.sendMessage(msg("warp-tp", "warp", key));
    }

    private boolean cmdWarp(CommandSender sender, String[] args) {
        Player p = soloJugador(sender);
        if (p == null) return true;
        if (args.length == 0) {
            abrirMenuWarps(p);
        } else {
            irAWarp(p, args[0]);
        }
        return true;
    }

    private boolean cmdSetWarp(CommandSender sender, String[] args) {
        if (!adminWarps(sender)) {
            sender.sendMessage(msg("sin-permiso"));
            return true;
        }
        Player p = soloJugador(sender);
        if (p == null) return true;
        if (args.length < 1) {
            p.sendMessage(msg("uso-setwarp"));
            return true;
        }
        String nombre = args[0].toLowerCase(Locale.ROOT);
        if (!nombre.matches("[a-z0-9_-]{1,32}")) {
            p.sendMessage(msg("nombre-invalido"));
            return true;
        }
        String base = "warps." + nombre;
        warpsCfg.set(base + ".ubicacion", p.getLocation());
        if (args.length >= 2) warpsCfg.set(base + ".descripcion", unir(args, 1));
        guardar(warpsCfg, warpsFile);
        p.sendMessage(msg("warp-creado", "warp", nombre));
        return true;
    }

    private boolean cmdDelWarp(CommandSender sender, String[] args) {
        if (!adminWarps(sender)) {
            sender.sendMessage(msg("sin-permiso"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(msg("uso-delwarp"));
            return true;
        }
        String nombre = args[0].toLowerCase(Locale.ROOT);
        if (!warpsCfg.contains("warps." + nombre)) {
            sender.sendMessage(msg("warp-no-existe", "warp", nombre));
            return true;
        }
        warpsCfg.set("warps." + nombre, null);
        guardar(warpsCfg, warpsFile);
        sender.sendMessage(msg("warp-borrado", "warp", nombre));
        return true;
    }

    private boolean cmdWarpDesc(CommandSender sender, String[] args) {
        if (!adminWarps(sender)) {
            sender.sendMessage(msg("sin-permiso"));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(msg("uso-warpdesc"));
            return true;
        }
        String nombre = args[0].toLowerCase(Locale.ROOT);
        if (!warpsCfg.contains("warps." + nombre)) {
            sender.sendMessage(msg("warp-no-existe", "warp", nombre));
            return true;
        }
        warpsCfg.set("warps." + nombre + ".descripcion", unir(args, 1));
        guardar(warpsCfg, warpsFile);
        sender.sendMessage(msg("warp-desc", "warp", nombre));
        return true;
    }

    // ================================================================ /menu

    private boolean cmdMenu(CommandSender sender, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!esAdmin(sender, "recargar", "semianarquico.menu.reload")) {
                sender.sendMessage(msg("sin-permiso"));
                return true;
            }
            reloadConfig();
            cargarDatos();
            detectarFloodgate();
            sender.sendMessage(msg("recargado"));
            return true;
        }
        Player p = soloJugador(sender);
        if (p == null) return true;
        String permMenu = permiso("menu", "semianarquico.menu");
        if (permMenu != null && !permMenu.isBlank() && !p.hasPermission(permMenu)) {
            p.sendMessage(msg("sin-permiso"));
            return true;
        }
        abrirMenuPrincipal(p);
        return true;
    }

    // ================================================================ comandos

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "menu":
                return cmdMenu(sender, args);
            case "kit":
                return cmdKit(sender, args);
            case "warp":
                return cmdWarp(sender, args);
            case "setwarp":
                return cmdSetWarp(sender, args);
            case "delwarp":
                return cmdDelWarp(sender, args);
            case "warpdesc":
                return cmdWarpDesc(sender, args);
            default:
                return false;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        List<String> opciones = new ArrayList<>();
        boolean admin = adminKits(sender);

        if (cmd.equals("kit")) {
            if (args.length == 1) {
                if (admin) opciones.addAll(List.of("create", "delete", "desc", "color", "icono"));
                opciones.add("list");
                opciones.addAll(nombresKits(null));
            } else if (args.length == 2 && admin
                    && (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("desc")
                    || args[0].equalsIgnoreCase("color") || args[0].equalsIgnoreCase("icono"))) {
                opciones.addAll(nombresKits(null));
            } else if (args.length == 4 && args[0].equalsIgnoreCase("create")) {
                opciones.addAll(categorias());
            }
        } else if (cmd.equals("warp") || cmd.equals("delwarp") || cmd.equals("warpdesc")) {
            if (args.length == 1) opciones.addAll(nombresWarps());
        } else if (cmd.equals("menu")) {
            if (args.length == 1) opciones.add("reload");
        }

        String actual = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        opciones.removeIf(o -> !o.toLowerCase(Locale.ROOT).startsWith(actual));
        return opciones;
    }
}
